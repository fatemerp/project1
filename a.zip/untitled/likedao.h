#ifndef LIKEDAO_H
#define LIKEDAO_H
#include <ctime>

#include <ctime>

#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
#include "like.h"
class LikeDAO {
public:
static bool createLike(like& ) ;

static QVector<like> getLikesByPostID(const QString& ) ;
};

#endif // LIKEDAO_H

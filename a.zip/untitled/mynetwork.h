
#ifndef MYNETWORK_H
#define MYNETWORK_H
#include <ctime>

#include <QMainWindow>

namespace Ui {
class myNetwork;
}

class myNetwork : public QMainWindow
{
Q_OBJECT

public:
explicit myNetwork(QWidget *parent = nullptr);
~myNetwork();

private slots:
void on_pushButton_clicked();

void on_pushButton_2_clicked();

void on_pushButton_3_clicked();

void on_pushButton_4_clicked();

private:
Ui::myNetwork *ui;
};

#endif // MYNETWORK_H

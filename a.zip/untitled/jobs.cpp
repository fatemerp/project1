
#include "jobs.h"
#include "ui_jobs.h"
#include "home.h"
#include "mynetwork.h"
#include "massaging.h"
#include "me.h"
#include <ctime>


jobs::jobs(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::jobs)
{
    ui->setupUi(this);
}

jobs::~jobs()
{
    delete ui;
}

void jobs::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void jobs::on_pushButton_2_clicked()
{
    home *jtr =new home;
    jtr-> setWindowTitle("home");
    jtr-> show();
}


void jobs::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void jobs::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}

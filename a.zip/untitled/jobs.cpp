
#include "jobs.h"
#include "ui_jobs.h"
#include "home.h"
#include "mynetwork.h"
#include "massaging.h"
#include "me.h"
#include <ctime>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "jobdao.h"
#include "job.h"
QVector<job*> myjobs;
jobs::jobs(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::jobs)
{
    ui->setupUi(this);
    /////
    QSqlQuery query;
    QString id;
    if (query.exec("SELECT sender_id FROM user")) {
        while (query.next()) {
            id = query.value(0).toString();
            break; // فقط اولین مقدار را بازیابی می‌کنیم
        }
    } else {
        qDebug() << "Failed to retrieve sender_id:" << query.lastError().text();
    }

    QString my_job;
    query.prepare("SELECT job FROM persons WHERE Account_ID = :account_id");
    query.bindValue(":account_id", id);
    if (query.exec()) {
        if (query.next()) {
            my_job = query.value(0).toString();
            QVector<job> jobs = JobDAO::getJobByName(my_job);//for append shouldnt be *
            for (const auto& j : jobs) {
                myjobs.append(new job(j));
            }
        }
    } else {
        qDebug() << "Failed to retrieve job:" << query.lastError().text();
    }

}
//



//
jobs::~jobs()
{
    delete ui;
}

void jobs::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void jobs::on_pushButton_2_clicked()
{
    home *jtr =new home;
    jtr-> setWindowTitle("home");
    jtr-> show();
}


void jobs::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void jobs::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}

void jobs::on_pushButton_6_clicked()
{
    if (!myjobs.isEmpty()) {
        job* job1 = myjobs.back();
        myjobs.pop_back();
        //show job info
         }
    if (!myjobs.isEmpty()) {
        job* job1 = myjobs.back();
        myjobs.pop_back();
        //show job info
         }
    if (!myjobs.isEmpty()) {
        job* job1 = myjobs.back();
        myjobs.pop_back();
        //show job info
         }



}


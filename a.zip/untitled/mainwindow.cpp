#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "home.h"
#include "cstring"
#include <ctime>

//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QSqlQuery q;
    QString name1 = ui->lineEdit->text();
    //QString pass1 = ui->lineEdit_5->text();

   // q.exec("INSERT INTO user (name , pass ) VALUES('"+name+"','"+pass+"')");
    //QSqlQueryModel *m =new QSqlQueryModel;
    //m->setQuery(q);
    ////bayad dar if ha beravad
    //if (q.first()) QMessageBox::warning(this,"incorrect captcha!","open sucsisfully","try again");




    q.exec("UPDATE user SET name='"+name1+"' ");
           //q.exec("INSERT INTO user (name) VALUES('"+name1+"')");


    ///
    home *jtr =new home;
    jtr-> setWindowTitle("home");
    jtr-> show();
}


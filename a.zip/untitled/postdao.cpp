
#include "postdao.h"
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "comment.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <ctime>

PostDAO::PostDAO()
{
    //data base
    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
}
      bool PostDAO::savePost(const post& post)
       {
        QSqlDatabase db = QSqlDatabase::database();
        QSqlQuery query(db);
        //query.prepare("INSERT INTO posts (post_id, reposet_counter, sender_id, time_sent, content_text, content_picture) "
                     //"VALUES (?, ?, ?, ?, ?, ?)");//get from karbar

        query.prepare("INSERT INTO post (post_id, reposet_counter, sender_id, time_sent, content_text)" "VALUES (?, ?, ?, ?, ?)");
///////////////////////////////////////rewrite ??????
        // ?? ???? ?????????? ????????? ???
        query.bindValue(0, post.Post_ID);
        query.bindValue(1, post.Reposet_counter);
        query.bindValue(2, post.sender_ID);
        query.bindValue(3, post.Time_sent.toString(Qt::ISODate));
        query.bindValue(4, post.Content_Text);
        //QByteArray imageData;
           // QBuffer buffer(&imageData);
           // buffer.open(QIODevice::WriteOnly);
           // post.Content_Picture.save(&buffer, "PNG");
            //query.bindValue(5, imageData);


        if (query.exec()) {

            saveLikes(post.Post_ID, post.Likes);
            saveComments(post.Post_ID, post.Comments);
            return true;
        } else {
            qDebug() << "Failed to save post:" << query.lastError().text();
            return false;
        }
    }


     void PostDAO::saveLikes(const QString& postId, const QVector<like*>& likes) {
        QSqlDatabase db = QSqlDatabase::database(); // ??????? ?? ?????? ???? ?????
            QSqlQuery query(db);
        query.prepare("INSERT INTO likes (post_id, who_liked_id, like_id, time) "
                         "VALUES (?, ?, ?, ?)");

            // ????? ??????? ?? ????
            for (const auto& like : likes) {
                query.bindValue(0, postId);
                query.bindValue(1, like->Who_liked_ID);
                query.bindValue(2, like->Like_ID);
                query.bindValue(3, like->Time.toString(Qt::ISODate));

                if (!query.exec()) {
                    qDebug() << "Failed to save like:" << query.lastError().text();
                }
            }
        // ?? ????? ?? ????? ??????? ???????
    }

   void  PostDAO:: saveComments(const QString& postId, const QVector<comment*>& comments) {
        QSqlDatabase db = QSqlDatabase::database(); // ??????? ?? ?????? ???? ?????
            QSqlQuery query(db);

            // ?????????? ????? SQL ???? ????? ??????? ?????
            query.prepare("INSERT INTO comments (post_id, comment_id, sender_id, time_sent, content_text) "
                         "VALUES (?, ?, ?, ?, ?)");
            //query.prepare("INSERT INTO comments (post_id, comment_id, sender_id, time_sent, content_text, content_picture) "
                        // "VALUES (?, ?, ?, ?, ?, ?)");

            // ????? ??????? ?? ???
            for (const auto& comment : comments) {
                query.bindValue(0, postId);
                query.bindValue(1, comment->comment_ID);
                query.bindValue(2, comment->sender_ID);
                query.bindValue(3, comment->Time_sent.toString(Qt::ISODate));
                query.bindValue(4, comment->Content_Text);

                // ????? QImage ?? QByteArray
                //QByteArray imageData;
                //QBuffer buffer(&imageData);
                //buffer.open(QIODevice::WriteOnly);
                //comment->Content_Picture.save(&buffer, "PNG"); // ????? ????? ?? ???? PNG
                //query.bindValue(5, imageData);

                if (!query.exec()) {
                    qDebug() << "Failed to save comment:" << query.lastError().text();
                }
            }
        // ?? ????? ?? ????? ??????? ?????
    }

        QVector<post*> PostDAO::getPostBySenderId(QString senderId) {
           QSqlDatabase db = QSqlDatabase::database();
           QSqlQuery query(db);

           query.prepare("SELECT * FROM post WHERE sender_id = ?");
           query.bindValue(0, senderId);

           if (!query.exec()) {
               qDebug() << "Failed to get post by sender ID:" << query.lastError().text();
               return {};
           }

           QVector<post*> posts;
           while (query.next()) {
               post* p = new post;
               p->Post_ID = query.value("post_id").toString();
               p->Reposet_counter = query.value("reposet_counter").toInt();
               p->sender_ID = query.value("sender_id").toString();
               //p->sender_ID = query.value("sender_id").toInt();
               p->Time_sent = QDateTime::fromString(query.value("time_sent").toString(), Qt::ISODate);
               p->Content_Text = query.value("content_text").toString();

               // Load the image data
               //QByteArray imageData = query.value("content_picture").toByteArray();
               //QBuffer buffer(&imageData);
               //buffer.open(QIODevice::ReadOnly);
               //p->Content_Picture.load(&buffer, "PNG");

               // Load likes and comments
               p->Likes = getLikes(p->Post_ID);
               p->Comments = getComments(p->Post_ID);

               posts.append(p);
           }

           return posts;
       }

         QVector<like*> PostDAO::getLikes(const QString& postId) {
            QSqlDatabase db = QSqlDatabase::database();
            QSqlQuery query(db);

            query.prepare("SELECT * FROM likes WHERE post_id = ?");
            query.bindValue(0, postId);

            if (!query.exec()) {
                qDebug() << "Failed to get likes for post:" << postId << " - " << query.lastError().text();
                return {};
            }

            QVector<like*> likes;
            while (query.next()) {
                like* l = new like;
                l->Like_ID = query.value("like_id").toString();
                l->Who_liked_ID = query.value("who_liked_id").toInt();
                l->Time = QDateTime::fromString(query.value("time").toString(), Qt::ISODate);
                likes.append(l);
            }

            return likes;
        }

         QVector<comment*> PostDAO::getComments(const QString& postId) {
            QSqlDatabase db = QSqlDatabase::database();
            QSqlQuery query(db);

            query.prepare("SELECT * FROM comments WHERE post_id = ?");
            query.bindValue(0, postId);

            if (!query.exec()) {
                qDebug() << "Failed to get comments for post:" << postId << " - " << query.lastError().text();
                return {};
            }

            QVector<comment*> comments;
            while (query.next()) {
                comment* c = new comment;
                c->comment_ID = query.value("comment_id").toString();
                c->sender_ID = query.value("sender_id").toInt();
                c->Time_sent = QDateTime::fromString(query.value("time_sent").toString(), Qt::ISODate);
                c->Content_Text = query.value("content_text").toString();

                // Load the image data
                //QByteArray imageData = query.value("content_picture").toByteArray();
                //QBuffer buffer(&imageData);
                //buffer.open(QIODevice::ReadOnly);
                //c->Content_Picture.load(&buffer, "PNG");

                comments.append(c);
            }

            return comments;
        }



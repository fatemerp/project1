
#include "home.h"
#include "ui_home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "massaging.h"
#include "me.h"
#include "content.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "start_post.h"
#include <ctime>

int a=1;

home::home(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::home)
{
    ui->setupUi(this);


}

home::~home()
{
    delete ui;
}

void home::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void home::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void home::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void home::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


void home::on_pushButton_5_clicked()
{

}


void home::on_pushButton_6_clicked()
{
    start_post *str =new start_post;
     str-> setWindowTitle("start_post");
     str-> show();
}


void home::on_pushButton_7_clicked()
{
    a+=10;
}


#include "home.h"
#include "ui_home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "massaging.h"
#include "me.h"
#include "content.h"
#include "post.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "postdao.h"
#include "start_post.h"
#include <ctime>
#include "postdao.h"
#include <QApplication>
#include <QLabel>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVBoxLayout>
#include <QWidget>
#include <accountdao.h>
int a=-9;
QVector<post*> posts;
home::home(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::home)
{
    ui->setupUi(this);
    ///
    QSqlQuery query;
    QString id;
    id= query.exec("SELECT sender_id FROM user ")   ;
    QString* following = new QString[20];
    following= accountDAO::getAccountFollowing(id);

    for (int i = 0; following[i] != nullptr; i++) {
        QString followedId = following[i];
        posts.append(PostDAO::getPostBySenderId(followedId));//like push_back but for string and zanciri
        delete[] following;
    }
   //int posts_size=posts.size();

    ////

}

home::~home()
{
    delete ui;

}




void home::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void home::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void home::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void home::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


void home::on_pushButton_5_clicked()
{

}


void home::on_pushButton_6_clicked()
{
    start_post *str =new start_post;
     str-> setWindowTitle("start_post");
     str-> show();
}


void home::on_pushButton_7_clicked()
{

    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        //ui->label_3->setText(a);
         }




}



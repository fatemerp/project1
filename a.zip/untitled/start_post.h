#ifndef START_POST_H
#define START_POST_H
#include <ctime>

#include <QMainWindow>

namespace Ui {
class start_post;
}

class start_post : public QMainWindow
{
Q_OBJECT

public:
explicit start_post(QWidget *parent = nullptr);
~start_post();

private:
Ui::start_post *ui;
};

#endif // START_POST_H

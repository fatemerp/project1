
#ifndef ACCOUNT_H
#define ACCOUNT_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include "post.h"
#include "directmassage.h"
#include <ctime>

class account
{
public:
account();
QString Account_ID;
QString Phone_number;
QString Email;
QString Connection;
QVector<QString> following;
QVector<post*> Posts;
QVector<directmassage*> DM;
};

#endif // ACCOUNT_H

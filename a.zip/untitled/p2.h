#ifndef P2_H
#define P2_H

#include <QMainWindow>

namespace Ui {
class p2;
}

class p2 : public QMainWindow
{
    Q_OBJECT

public:
    explicit p2(QWidget *parent = nullptr);
    ~p2();

private:
    Ui::p2 *ui;
};

#endif // P2_H

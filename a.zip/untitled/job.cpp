#include "job.h"

job::job()
{

}

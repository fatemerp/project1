
#ifndef POSTDAO_H
#define POSTDAO_H
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "comment.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <ctime>

class PostDAO {
public:
PostDAO();
static bool savePost(const post& post);


private:
static void saveLikes(const QString& , const QVector<like*>& ) ;

static void saveComments(const QString& , const QVector<comment*>& ) ;

};


#endif // POSTDAO_H

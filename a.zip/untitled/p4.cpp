#include "p4.h"
#include "ui_p4.h"

p4::p4(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::p4)
{
    ui->setupUi(this);
}

p4::~p4()
{
    delete ui;
}

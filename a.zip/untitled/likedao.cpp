
#include "likedao.h"
#include <ctime>
//LikeDAO::
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
#include "postdao.h"
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "comment.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>

     bool LikeDAO::createLike(like& l) {
        QSqlQuery query;
        query.prepare("INSERT INTO likes (Who_liked_ID, Like_ID, Time) VALUES (?, ?, ?)");
        query.addBindValue(l.Who_liked_ID);
        query.addBindValue(l.Like_ID);
        query.addBindValue(l.Time.toString("yyyy-MM-dd HH:mm:ss"));
        if (!query.exec()) {
            qDebug() << "Error creating like:" << query.lastError().text();
            return false;
        }
        return true;
    }

     QVector<like> LikeDAO::getLikesByPostID(const QString& postID) {
        QVector<like> likes;
        QSqlQuery query;
        query.prepare("SELECT * FROM likes WHERE Like_ID = ?");
        query.addBindValue(postID);
        if (!query.exec()) {
            qDebug() << "Error getting likes:" << query.lastError().text();
            return likes;
        }
        while (query.next()) {
            like l;
            l.Who_liked_ID = query.value(0).toString();
            l.Like_ID = query.value(1).toString();
            l.Time = QDateTime::fromString(query.value(2).toString(), "yyyy-MM-dd HH:mm:ss");
            likes.append(l);
        }
        return likes;
    }

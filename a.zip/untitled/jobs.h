#ifndef JOBS_H
#define JOBS_H

#include <QMainWindow>
#include <ctime>

namespace Ui {
class jobs;
}

class jobs : public QMainWindow
{
Q_OBJECT

public:
explicit jobs(QWidget *parent = nullptr);
~jobs();

private slots:
void on_pushButton_2_clicked();

void on_pushButton_clicked();

void on_pushButton_3_clicked();

void on_pushButton_4_clicked();

void on_pushButton_6_clicked();

private:
Ui::jobs *ui;
};

#endif // JOBS_H

#ifndef ACCOUNTDAO_H
#define ACCOUNTDAO_H


//class accountDAO
//{
//public:
//   accountDAO();
//};

//#endif // ACCOUNTDAO_H


#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "account.h"
#include "comment.h"
#include "post.h"
#include "directmassage.h"
#include "postdao.h"
#include "directmassage.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <ctime>

//accountDAO::accountDAO()
//{

//}
class accountDAO {
public:
  //accountDAO::accountDAO();
 static void saveAccount(const account& ) ;

private:
 static void saveAccountPosts(const QString& , const QVector<post*>& ) ;

 static void saveAccountDirectMessages(const QString& , const QVector<directmassage*>& ) ;

  static void saveAccountFollowing(const QString&  , const QVector<QString>&  ) ;
};
#endif

#ifndef P5_H
#define P5_H

#include <QMainWindow>

namespace Ui {
class p5;
}

class p5 : public QMainWindow
{
    Q_OBJECT

public:
    explicit p5(QWidget *parent = nullptr);
    ~p5();

private:
    Ui::p5 *ui;
};

#endif // P5_H

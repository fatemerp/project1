#include "post.h"

post::post()
{

}

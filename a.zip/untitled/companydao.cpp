

#include "companydao.h"
#include <ctime>

//CompanyDAO::CompanyDAO()
//{

//}
//#ifndef COMPANYDAO_H
//#define COMPANYDAO_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "time.h"
#include "company.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
// ?? ??? directmassagedao.cpp
#include "directmessagedao.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>


#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
//CompanyDAO::
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QStringList>
#include <QVector>

#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
     QString CompanyDAO::serializeVector(const QVector<QString>& v) {
    QString result;
    QByteArray buffer;
    QDataStream stream(&buffer, QIODevice::WriteOnly);
    stream << v;
    result = QString::fromUtf8(buffer.toBase64());
    return result;
   }

    QVector<QString> CompanyDAO::deserializeVector(const QString& s) {
    QByteArray buffer = QByteArray::fromBase64(s.toUtf8());
    QDataStream stream(&buffer, QIODevice::ReadOnly);
    QVector<QString> result;
    stream >> result;
    return result;
    }

     bool CompanyDAO::saveCompany(company& c) {
        QSqlQuery query;
        query.prepare("INSERT INTO companies (Company_ID, Company_Name, Employees, Followers, Company_Jobs) VALUES (?, ?, ?, ?, ?)");
        query.addBindValue(c.Account_ID);
        query.addBindValue(c.Company_name);
        query.addBindValue(serializeVector(c.Employee));
        query.addBindValue(serializeVector(c.following));
        query.addBindValue(serializeVector(c.Company_Jobs));
        if (!query.exec()) {
            qDebug() << "Error saving company:" << query.lastError().text();
            return false;
        }
        return true;
    }

     QVector<company> CompanyDAO::getAllCompanies() {
        QVector<company> companies;
        QSqlQuery query("SELECT * FROM companies");
        while (query.next()) {
            company c;
            c.Account_ID = query.value(0).toString();
            c.Company_name = query.value(1).toString();
            c.Employee = deserializeVector(query.value(2).toString());
            c.following = deserializeVector(query.value(3).toString());
            c.Company_Jobs = deserializeVector(query.value(4).toString());
            companies.append(c);
        }
        return companies;
    }

     QVector<company> CompanyDAO::getCompaniesByJob(const QString& job_name) {
         QVector<company> companies;
         QVector<company> all_companies = getAllCompanies();
         for (const auto& c : all_companies) {
             if (c.Company_Jobs.contains(job_name)) {
                 companies.append(c);
             }
         }
         return companies;
     }


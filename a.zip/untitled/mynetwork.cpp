
#include "mynetwork.h"
#include "ui_mynetwork.h"
#include "home.h"
#include "jobs.h"
#include "massaging.h"
#include "me.h"
#include <ctime>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "jobdao.h"
#include "job.h"
#include "person.h"
#include "persondao.h"
#include "company.h"
#include "companydao.h"

QVector<person>suggest1;
//QVector<company>suggest2;

myNetwork::myNetwork(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::myNetwork)
{
    ui->setupUi(this);
    ///
    QSqlQuery query;
    QString id;
    if (query.exec("SELECT sender_id FROM user")) {
        while (query.next()) {
            id = query.value(0).toString();
            break; // just first one
        }
    } else {
        qDebug() << "Failed to retrieve sender_id:" << query.lastError().text();
    }

    QString my_job;
    query.prepare("SELECT job FROM persons WHERE Account_ID = :account_id");
    query.bindValue(":account_id", id);
    if (query.exec()) {
        if (query.next()) {
            my_job = query.value(0).toString();
            suggest1 = PersonDAO::getPersonsByJob(my_job);
            //suggest2 = CompanyDAO::getCompaniesByJob(my_job);
        }
    } else {
        qDebug() << "Failed to retrieve job:" << query.lastError().text();
    }

}

myNetwork::~myNetwork()
{
    delete ui;
}


void myNetwork::on_pushButton_clicked()
{
   home *mtr =new home;
    mtr-> setWindowTitle("home");
    mtr-> show();
}


void myNetwork::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void myNetwork::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void myNetwork::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


#include "mynetwork.h"
#include "ui_mynetwork.h"
#include "home.h"
#include "jobs.h"
#include "massaging.h"
#include "me.h"
#include <ctime>

myNetwork::myNetwork(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::myNetwork)
{
    ui->setupUi(this);
}

myNetwork::~myNetwork()
{
    delete ui;
}


void myNetwork::on_pushButton_clicked()
{
   home *mtr =new home;
    mtr-> setWindowTitle("home");
    mtr-> show();
}


void myNetwork::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void myNetwork::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void myNetwork::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}

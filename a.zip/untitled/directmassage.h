#ifndef DIRECTMASSAGE_H
#define DIRECTMASSAGE_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include "content.h"
#include <ctime>

class directmassage: public content
{
public:
directmassage();
QString Message_ID;
QString To_who;
};

#endif // DIRECTMASSAGE_H

#ifndef CONTENT_H
#define CONTENT_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include <ctime>
//#include "time.h"
class content
{
public:
content();
QString sender_ID;
QDateTime Time_sent;
QString Content_Text;
//QImage Content_Picture;
//QVideo Content_Video;
};

#endif // CONTENT_H


#include "commentdao.h"
#include <ctime>

//CommentDAO::


#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
#include <QBuffer>


     bool CommentDAO::createComment(comment& c) {
        QSqlQuery query;
        query.prepare("INSERT INTO comments (Post_ID, comment_ID, sender_ID, Time_sent, Content_Text, Content_Picture) VALUES (?, ?, ?, ?, ?, ?)");
        query.addBindValue(c.Post_ID);
        query.addBindValue(c.comment_ID);
        query.addBindValue(c.sender_ID);
        query.addBindValue(c.Time_sent.toString("yyyy-MM-dd HH:mm:ss"));
        query.addBindValue(c.Content_Text);
        QByteArray imageData;
        QBuffer buffer(&imageData);
        buffer.open(QIODevice::WriteOnly);
        c.Content_Picture.save(&buffer, "PNG");
        query.addBindValue(imageData.toBase64());
        if (!query.exec()) {
            qDebug() << "Error creating comment:" << query.lastError().text();
            return false;
        }
        return true;
    }

     QVector<comment> CommentDAO::getCommentsByPostID(const QString& postID) {
        QVector<comment> comments;
        QSqlQuery query;
        query.prepare("SELECT * FROM comments WHERE Post_ID = ?");
        query.addBindValue(postID);
        if (!query.exec()) {
            qDebug() << "Error getting comments:" << query.lastError().text();
            return comments;
        }
        while (query.next()) {
            comment c;
            c.Post_ID = query.value(0).toString();
            c.comment_ID = query.value(1).toString();
            c.sender_ID = query.value(2).toString();
            c.Time_sent = QDateTime::fromString(query.value(3).toString(), "yyyy-MM-dd HH:mm:ss");
            c.Content_Text = query.value(4).toString();
            QByteArray imageData = QByteArray::fromBase64(query.value(5).toByteArray());
            c.Content_Picture.loadFromData(imageData);
            comments.append(c);
        }
        return comments;
    }

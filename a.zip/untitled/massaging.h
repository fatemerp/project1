#ifndef MASSAGING_H
#define MASSAGING_H
#include <ctime>

#include <QMainWindow>

namespace Ui {
class massaging;
}

class massaging : public QMainWindow
{
Q_OBJECT

public:
explicit massaging(QWidget *parent = nullptr);
~massaging();

private slots:
void on_pushButton_3_clicked();

void on_pushButton_clicked();

void on_pushButton_2_clicked();

void on_pushButton_4_clicked();

private:
Ui::massaging *ui;
};

#endif // MASSAGING_H


#include "massaging.h"
#include "ui_massaging.h"
#include "home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "me.h"
#include <ctime>

massaging::massaging(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::massaging)
{
    ui->setupUi(this);
}

massaging::~massaging()
{
    delete ui;
}


void massaging::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void massaging::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void massaging::on_pushButton_3_clicked()
{
    home *mstr =new home;
    mstr-> setWindowTitle("home");
    mstr-> show();
}


void massaging::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


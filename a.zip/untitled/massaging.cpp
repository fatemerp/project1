
#include "massaging.h"
#include "ui_massaging.h"
#include "home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "me.h"
#include <ctime>
#include <qdebug.h>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "directmessagedao.h"
#include "person.h"
#include "persondao.h"
#include "p1.h"
#include "p2.h"
#include "p3.h"
#include "p4.h"
#include "p5.h"
QVector <QString> intouch;
person pp1;
person pp2;
person pp3;
person pp4;
person pp5;
QString person1,person2,person3,person4,person5;

massaging::massaging(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::massaging)
{
    ui->setupUi(this);
    //
    QSqlQuery query;
    QString id;
    if (query.exec("SELECT sender_id FROM user")) {
        while (query.next()) {
            id = query.value(0).toString();
            break; // just 1th
        }
        std::vector<QString> accountIDs = DirectMessageDAO::getAccountIDsWithDirectMessages(id);
        for (const auto& accountID : accountIDs) {
            intouch.append(accountID);
        }
        if (!intouch.isEmpty()) {
             person1 = intouch.back();
            intouch.pop_back();
            pp1=PersonDAO::getPersonByAccountId(person1);
            ///namayesh pish namayesh p1

             }
        if (!intouch.isEmpty()) {
             person2 = intouch.back();
            intouch.pop_back();
             pp2=PersonDAO::getPersonByAccountId(person2);
            ///namayesh pish namayesh p2

             }
        if (!intouch.isEmpty()) {
             person3 = intouch.back();
            intouch.pop_back();
            pp3=PersonDAO::getPersonByAccountId(person3);
           ///namayesh pish namayesh p3

             }
        if (!intouch.isEmpty()) {
             person4 = intouch.back();
            intouch.pop_back();
            pp4=PersonDAO::getPersonByAccountId(person4);
           ///namayesh pish namayesh p4

             }
        if (!intouch.isEmpty()) {
             person5 = intouch.back();
            intouch.pop_back();
            pp5=PersonDAO::getPersonByAccountId(person5);
           ///namayesh pish namayesh p5

             }
    }


}

massaging::~massaging()
{
    delete ui;
}


void massaging::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void massaging::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void massaging::on_pushButton_3_clicked()
{
    home *mstr =new home;
    mstr-> setWindowTitle("home");
    mstr-> show();
}


void massaging::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


void massaging::on_pushButton_6_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person1);
    p1 *mtr =new p1;
     mtr-> setWindowTitle("chats");
     mtr-> show();

}


void massaging::on_pushButton_7_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person2);
    p2 *mtr =new p2;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


void massaging::on_pushButton_8_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person3);
    p3 *mtr =new p3;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


void massaging::on_pushButton_9_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person4);
    p4 *mtr =new p4;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


void massaging::on_pushButton_10_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person5);
    p5 *mtr =new p5;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


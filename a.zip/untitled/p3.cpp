#include "p3.h"
#include "ui_p3.h"

p3::p3(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::p3)
{
    ui->setupUi(this);
}

p3::~p3()
{
    delete ui;
}

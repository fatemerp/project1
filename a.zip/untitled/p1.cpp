#include "p1.h"
#include "ui_p1.h"

p1::p1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::p1)
{
    ui->setupUi(this);
}

p1::~p1()
{
    delete ui;
}

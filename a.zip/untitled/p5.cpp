#include "p5.h"
#include "ui_p5.h"

p5::p5(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::p5)
{
    ui->setupUi(this);
}

p5::~p5()
{
    delete ui;
}

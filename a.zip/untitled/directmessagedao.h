
#ifndef DIRECTMASSAGEDAO_H
#define DIRECTMASSAGEDAO_H

#include <string>
#include <vector>
#include "directmassage.h"
#include <QIODevice>
#include <QBuffer>
#include <ctime>

// ?? ??? directmassagedao.h


#include <string>
#include <vector>
#include "directmassage.h"
#include <QIODevice>
#include <QBuffer>

class DirectMessageDAO {
public:
    static bool saveDirectMessage(const directmassage& directMessage);
    static std::vector<directmassage> getAllDirectMessages();
    static directmassage getDirectMessageByID(const QString& massageID);
    static bool updateDirectMessage(const directmassage& directMessage);
    static bool deleteDirectMessageByID(const QString& massageID);

private:
    static QIODevice* getConnection();
};

#endif // DIRECTMASSAGEDAO_H


#ifndef DIRECTMASSAGEDAO_H
#define DIRECTMASSAGEDAO_H

#include <string>
#include <vector>
#include "directmassage.h"
#include <QIODevice>
#include <QBuffer>
#include <ctime>

// ?? ??? directmassagedao.h

#include "person.h"
#include <string>
#include <vector>
#include "directmassage.h"
#include <QIODevice>
#include <QBuffer>

class DirectMessageDAO {
public:
    static bool saveDirectMessage(const directmassage& directMessage);
    static std::vector<directmassage> getAllDirectMessages();
    static directmassage getDirectMessageByID(const QString& massageID);
    static bool updateDirectMessage(const directmassage& directMessage);
    static bool deleteDirectMessageByID(const QString& massageID);
    static std::vector<directmassage> getDirectMessagesBetween(const QString& , const QString&);
    static std::vector<directmassage> getDirectMessagesByAccountID(const QString& );
    static std::vector<QString> getAccountIDsWithDirectMessages(const QString& );
private:
    static QIODevice* getConnection();
};

#endif // DIRECTMASSAGEDAO_H

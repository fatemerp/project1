
#include "me.h"
#include "ui_me.h"
#include "home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "massaging.h"
#include <ctime>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "person.h"
#include "persondao.h"
me::me(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::me)
{
    ui->setupUi(this);
    /////
    QSqlQuery query;
    QString id;
    id= query.exec("SELECT sender_id FROM user ")   ;
     person me =PersonDAO::getPersonByAccountId(id);
//set page:



}

me::~me()
{
    delete ui;
}


void me::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void me::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void me::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void me::on_pushButton_4_clicked()
{
    home *metr =new home;
    metr-> setWindowTitle("home");
    metr-> show();
}


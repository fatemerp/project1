#include "person.h"

person::person()
{

}

#ifndef ME_H
#define ME_H
#include <ctime>
#include <ctime>
#include <ctime>

#include <QMainWindow>

namespace Ui {
class me;
}

class me : public QMainWindow
{
Q_OBJECT

public:
explicit me(QWidget *parent = nullptr);
~me();

private slots:
void on_pushButton_4_clicked();

void on_pushButton_clicked();

void on_pushButton_2_clicked();

void on_pushButton_3_clicked();

private:
Ui::me *ui;
};

#endif // ME_H

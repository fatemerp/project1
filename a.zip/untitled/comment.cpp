#include "comment.h"

comment::comment()
{

}

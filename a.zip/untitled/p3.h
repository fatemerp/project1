#ifndef P3_H
#define P3_H

#include <QMainWindow>

namespace Ui {
class p3;
}

class p3 : public QMainWindow
{
    Q_OBJECT

public:
    explicit p3(QWidget *parent = nullptr);
    ~p3();

private:
    Ui::p3 *ui;
};

#endif // P3_H

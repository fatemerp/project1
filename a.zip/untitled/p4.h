#ifndef P4_H
#define P4_H

#include <QMainWindow>

namespace Ui {
class p4;
}

class p4 : public QMainWindow
{
    Q_OBJECT

public:
    explicit p4(QWidget *parent = nullptr);
    ~p4();

private:
    Ui::p4 *ui;
};

#endif // P4_H

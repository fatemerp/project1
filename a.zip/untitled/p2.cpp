#include "p2.h"
#include "ui_p2.h"

p2::p2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::p2)
{
    ui->setupUi(this);
}

p2::~p2()
{
    delete ui;
}


#include "start_post.h"
#include "ui_start_post.h"
#include "postdao.h"
#include <ctime>
#include "post.h"
#include "content.h"
#include "home.h"
//#include "mywidget.h"

start_post::start_post(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::start_post)
{

    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    ui->setupUi(this);
}

start_post::~start_post()
{
    delete ui;
}



void start_post::on_pushButton_clicked()
{

    //QSqlDatabase db = QSqlDatabase::database();
    //QSqlQuery query(db);
QSqlQuery query;

    post post1;
    post1.sender_ID =query.exec("SELECT sender_id FROM user ");

    post1.Content_Text= ui-> lineEdit ->text();


    //////
    int b;
    query.exec("SELECT count FROM post_counter");
    if (query.exec()) {
        if (query.next()) {
            b = query.value(0).toInt() + 1;
        } else {
            b = 1; // If the table is empty, start from 1
        }
    } else {
        qDebug() << "Failed to execute SELECT query:" << query.lastError().text();
    }


    query.prepare("UPDATE post_counter SET count = :count");
    query.bindValue(":count", b);
    if (!query.exec()) {
        qDebug() << "Error updating post_counter: " << query.lastError().text();
    }

    if (!query.exec()) {
        qDebug() << "Failed to execute UPDATE query:" << query.lastError().text();
    }
    //////
    post1.Post_ID=query.exec("SELECT count FROM post_counter ");
    post1.Reposet_counter=0;

    post1.Time_sent= QDateTime::currentDateTime();
    if(PostDAO::savePost( post1)) {
        home *metr =new home;
        metr-> setWindowTitle("home");
        metr-> show();
    }


}


void start_post::on_pushButton_2_clicked()
{

}


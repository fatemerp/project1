
#include "start_post.h"
#include "ui_start_post.h"
#include "postdao.h"
#include <ctime>

start_post::start_post(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::start_post)
{
    ui->setupUi(this);
}

start_post::~start_post()
{
    delete ui;
}


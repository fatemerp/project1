#ifndef JOBDAO_H
#define JOBDAO_H


#include <ctime>

#include "job.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>

class JobDAO {
public:
static bool createJob(job&  ) ;

static QVector<job> getAllJobs() ;
private:
static QString serializeVector(const QVector<QString>&  ) ;

static QVector<QString> deserializeVector(const QString&  ) ;
};


#endif // JOBDAO_H

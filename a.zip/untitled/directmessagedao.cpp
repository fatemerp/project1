#include "directmessagedao.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "time.h"
#include "comment.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
// ?? ??? directmassagedao.cpp
#include "directmassage.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <ctime>

// ?? ??? directmassagedao.cpp
//#include "directmassagedao.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <QDateTime>

bool DirectMessageDAO::saveDirectMessage(const directmassage& directMessage) {
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return false;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO posts (sender_ID, Time_sent, Content_Text, Massage_ID, To_who) VALUES (?, ?, ?, ?, ?)");
    query.addBindValue(directMessage.sender_ID);
    query.addBindValue(directMessage.Time_sent.toString(Qt::ISODate));
    query.addBindValue(directMessage.Content_Text);
    query.addBindValue(directMessage.Message_ID);
    query.addBindValue(directMessage.To_who);

    if (!query.exec()) {
        qDebug() << "Error executing SQL query:" << query.lastError().text();
        return false;
    }

    return true;
}

std::vector<directmassage> DirectMessageDAO::getAllDirectMessages() {
    std::vector<directmassage> directMessages;
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return directMessages;
    }

    QSqlQuery query("SELECT * FROM posts");
    while (query.next()) {
        directmassage directMessage;
        directMessage.sender_ID = query.value(0).toString();
        directMessage.Time_sent = QDateTime::fromString(query.value(1).toString(), Qt::ISODate);
        directMessage.Content_Text = query.value(2).toString();
        directMessage.Message_ID = query.value(3).toString();
        directMessage.To_who = query.value(4).toString();
        directMessages.push_back(directMessage);
    }

    return directMessages;
}

directmassage DirectMessageDAO::getDirectMessageByID(const QString& massageID) {
    directmassage directMessage;
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return directMessage;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM posts WHERE Massage_ID = ?");
    query.addBindValue(massageID);
    if (!query.exec()) {
        qDebug() << "Error executing SQL query:" << query.lastError().text();
        return directMessage;
    }

    if (query.next()) {
        directMessage.sender_ID = query.value(0).toString();
        directMessage.Time_sent = QDateTime::fromString(query.value(1).toString(), Qt::ISODate);
        directMessage.Content_Text = query.value(2).toString();
        directMessage.Message_ID = query.value(3).toString();
        directMessage.To_who = query.value(4).toString();
    }

    return directMessage;
}

QIODevice* DirectMessageDAO::getConnection() {
    // Your implementation...
}

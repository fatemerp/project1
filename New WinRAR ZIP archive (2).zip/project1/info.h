#ifndef INFO_H
#define INFO_H

#include <QMainWindow>

namespace Ui {
class confing_1;
}

class confing_1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit confing_1(QWidget *parent = nullptr);
    ~confing_1();

private:
    Ui::confing_1 *ui;
};

#endif // INFO_H

#ifndef LOG_IN_PAGE_H
#define LOG_IN_PAGE_H

#include <QMainWindow>

namespace Ui {
class log_in_page;
}

class log_in_page : public QMainWindow
{
    Q_OBJECT

public:
    explicit log_in_page(QWidget *parent = nullptr);
    ~log_in_page();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();



    void on_pushButton_2_clicked();



private:
    Ui::log_in_page *ui;
};

#endif // LOG_IN_PAGE_H

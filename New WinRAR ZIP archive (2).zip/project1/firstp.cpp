#include "firstp.h"
#include "ui_firstp.h"
#include "QDebug"
#include "QPixmap"
#include"QPainter"
#include "log_in_page.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
firstP::firstP(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::firstP)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\linkedin.db");
    database.open();
    //
    QPixmap background("d:\\New folder\\images (1).jpg");
    QPalette palette;
    palette.setBrush(QPalette::Background, background);
    ui->groupBox_2->setAutoFillBackground(true);
    ui->groupBox_2->setPalette(palette);



}

firstP::~firstP()
{
    delete ui;
}








void firstP::on_pushButton1_clicked()
{
      log_in_page *l =new log_in_page;
      l->setWindowTitle("log in !");
      l->show();

}


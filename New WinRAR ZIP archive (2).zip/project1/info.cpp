#include "info.h"
#include "ui_info.h"



confing_1::confing_1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::confing_1)
{
    ui->setupUi(this);

}

confing_1::~confing_1()
{
    delete ui;
}

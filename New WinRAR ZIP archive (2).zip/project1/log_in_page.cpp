#include "log_in_page.h"
#include "ui_log_in_page.h"
#include "QMessageBox"
#include "confing_code.h"
#include "cstring"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
int r;
struct data{
    char name[20];
    char pass[20];
};

data dataes[20];

int n=1;

log_in_page::log_in_page(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::log_in_page)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\linkedin.db");
    database.open();
    //
}

log_in_page::~log_in_page()
{
    delete ui;
}


void log_in_page::on_pushButton_clicked()
{
r = rand ()%3;
    if (r==0){
        QPixmap background("d:\\New folder\\EQAWO.png");
        QPalette palette;
        palette.setBrush(QPalette::Background, background);
        ui->groupBox->setAutoFillBackground(true);
        ui->groupBox->setPalette(palette);
    }

    if (r==1){
        QPixmap background("d:\\New folder\\images (1).png");
        QPalette palette;
        palette.setBrush(QPalette::Background, background);
        ui->groupBox->setAutoFillBackground(true);
        ui->groupBox->setPalette(palette);
    }

    if (r==2){
        QPixmap background("d:\\New folder\\images.png");
        QPalette palette;
        palette.setBrush(QPalette::Background, background);
        ui->groupBox->setAutoFillBackground(true);
        ui->groupBox->setPalette(palette);
    }


}


void log_in_page::on_pushButton_3_clicked()
{int bul=0;
    //database
    QSqlQuery q;
    QString name = ui->lineEdit->text();
    QString pass = ui->lineEdit_2->text();
    QString ipass ;
    q.exec("SELECT pass word FROM user WHERE user name= '"+name+"'");
     if (true){
        ipass=(q.value(0).toString());
         if( ipass == pass ){
            bul=1;
        }
         if (bul==0) QMessageBox::warning(this,"incorrect information!","the password or user name is incorrect try again","try again");
         if (bul==1) {
             if (r==0){
                if(ui->lineEdit_3->text()=="fdamc") {
                    confing_code *c =new confing_code;
                    c->show();
                }
                else {
                    QMessageBox::warning(this,"incorrect captcha!","the chaptcha code is incorrect try again","try again");
                    ui->lineEdit_3->setText(" ");


                }
             }

             if (r==1){
                 if(ui->lineEdit_3->text()=="RecAPtDhA") {
                     confing_code *c =new confing_code;
                     c->show();

                 }
                 else {
                     QMessageBox::warning(this,"incorrect captcha!","the chaptcha code is incorrect try again","try again");
                     ui->lineEdit_3->setText(" ");


                 }
             }

             if (r==2){
                 if(ui->lineEdit_3->text()=="smwm") {
                     confing_code *c =new confing_code;
                     c->show();
                 }

                 else {
                     QMessageBox::warning(this,"incorrect captcha!","the chaptcha code is incorrect try again","try again");
                     ui->lineEdit_3->setText(" ");

                 }
             }

         }
    }

    //
      else QMessageBox::warning(this,"incorrect information!","the user name is unavailable ","try again");
}










void log_in_page::on_pushButton_2_clicked()
{
    QSqlQuery q;
    QString name = ui->lineEdit_4->text();
    QString pass = ui->lineEdit_5->text();
    q.exec("INSERT INTO user (user name , pass word) VALUES('"+name+"','"+pass+"')");
    ////bayad dar if ha beravad
    if (r==0){
       if(ui->lineEdit_3->text()=="fdamc") {
           confing_code *c =new confing_code;
           c->show();
       }
       else {
           QMessageBox::warning(this,"incorrect captcha!","the chaptcha code is incorrect try again","try again");
           ui->lineEdit_3->setText(" ");


       }
    }

    if (r==1){
        if(ui->lineEdit_3->text()=="RecAPtDhA") {
            confing_code *c =new confing_code;
            c->show();

        }
        else {
            QMessageBox::warning(this,"incorrect captcha!","the chaptcha code is incorrect try again","try again");
            ui->lineEdit_3->setText(" ");


        }
    }

    if (r==2){
        if(ui->lineEdit_3->text()=="smwm") {
            confing_code *c =new confing_code;
            c->show();
        }

        else {
            QMessageBox::warning(this,"incorrect captcha!","the chaptcha code is incorrect try again","try again");
            ui->lineEdit_3->setText(" ");

        }
    }
}


//void log_in_page::on_pushButton_4_clicked()
//{
//  QSqlQuery q;
//   q.exec("SELECT * FROM user");
//   QSqlQueryModel *m =new QSqlQueryModel;
//   m->setQuery(q);

//   ui->tableView->setModel (m);
//}


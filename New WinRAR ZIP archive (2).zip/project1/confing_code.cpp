#include "confing_code.h"
#include "ui_confing_code.h"
#include "QMessageBox"
#include "information.h"

int c1;
confing_code::confing_code(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::confing_code)
{
    ui->setupUi(this);
    c1=rand()%4;
    if(c1==0) QMessageBox::information(this,"config code!","the config code is : 4682","ok");
    if(c1==1) QMessageBox::information(this,"config code!","the config code is : 1420","ok");
    if(c1==2) QMessageBox::information(this,"config code!","the config code is : 7381","ok");
    if(c1==3) QMessageBox::information(this,"config code!","the config code is : 9316","ok");
}

confing_code::~confing_code()
{
    delete ui;
}






void confing_code::on_pushButton_2_clicked()
{
    if (c1==0){
           if(ui->lineEdit->text()=="4682") {
               information *i =new information;
               i->show();
           }
           else {
               QMessageBox::warning(this,"incorrect confing code","incorrect confing code!!","try again");
               ui->lineEdit->setText(" ");


           }
        }
    if (c1==1){
            if(ui->lineEdit->text()=="1420") {
                information *i =new information;
                i->show();
            }
            else {
                QMessageBox::warning(this,"incorrect confing code","incorrect confing code!!","try again");
                ui->lineEdit->setText(" ");


            }
        }

        if (c1==2){
            if(ui->lineEdit->text()=="7381") {
                information *i =new information;
                i->show();
            }
            else {
                QMessageBox::warning(this,"incorrect confing code","incorrect confing code!!","try again");
                ui->lineEdit->setText(" ");


            }
        }
            if (c1==3){
                if(ui->lineEdit->text()=="9316") {
                   information *i =new information;
                    i->show();
                }
                else {
                    QMessageBox::warning(this,"incorrect confing code","incorrect confing code!!","try again");
                    ui->lineEdit->setText(" ");


                }
    }

}


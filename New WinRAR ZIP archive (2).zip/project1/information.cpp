#include "information.h"
#include "ui_information.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//

information::information(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::information)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\linkedin.db");
    database.open();
    //
}

information::~information()
{
    delete ui;
}

void information::on_pushButton_clicked()
{
    QSqlQuery q;
    QString s1,s2,s3,s4;
    s1=ui-> lineEdit ->text();
    s2=ui-> lineEdit_2 ->text();
    s3=ui-> lineEdit_3 ->text();
    s4=ui-> lineEdit_4 ->text();
    q.exec("INSERT INTO user(birth date,job,the company,study place)VALUES('"+s1+"','"+s2+"','"+s3+"','"+s4+"') ");
}


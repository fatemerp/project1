#ifndef JOB_H
#define JOB_H
#include "QDateTime"
#include"QVector"
#include "QImage"

#include <ctime>
class job
{
public:
job();
QString job_name;
QString Company_name;
QVector<QString> Skills_required;
QString workPlace_type;
QString location;
QString type;
int salary;
};

#endif // JOB_H

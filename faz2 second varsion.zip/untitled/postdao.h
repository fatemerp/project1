
#ifndef POSTDAO_H
#define POSTDAO_H
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "comment.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <ctime>

class PostDAO {
public:
PostDAO();
static bool savePost(const post& post);
static void saveLikes(const QString& , const QVector<like*>& ) ;
static void saveComments(const QString& , const QVector<comment*>& ) ;
static QVector<post*> getPostBySenderId(QString senderId);
private:
static QVector<like*> getLikes(const QString&  ) ;
static QVector<comment*> getComments(const QString&  ) ;

};


#endif // POSTDAO_H

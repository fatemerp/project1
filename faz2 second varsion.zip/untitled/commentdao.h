#ifndef COMMENTDAO_H
#define COMMENTDAO_H
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
#include <QBuffer>
#include "comment.h"
#include <ctime>

class CommentDAO {
public:
static bool createComment(comment& ) ;

static QVector<comment> getCommentsByPostID(const QString& ) ;
};

#endif // COMMENTDAO_H

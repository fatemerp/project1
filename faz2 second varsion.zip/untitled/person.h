#ifndef PERSON_H
#define PERSON_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include "account.h"
#include "job.h"
#include <ctime>

class person : public account
{
public:
person();
QString Last_Name;
QString First_Name;
QString Job;
QVector<QString> Skills;
void Take_Job( job) {}
};

#endif // PERSON_H

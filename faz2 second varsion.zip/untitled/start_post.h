#ifndef START_POST_H
#define START_POST_H
#include <ctime>
//#include "mywidget.h"

#include <QMainWindow>

namespace Ui {

class start_post;
}

class start_post : public QMainWindow
{


Q_OBJECT
public:
QImage Content_Picture;

explicit start_post(QWidget *parent = nullptr);
~start_post();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
Ui::start_post *ui;
};

#endif // START_POST_H



#include "companydao.h"
#include <ctime>

//CompanyDAO::CompanyDAO()
//{

//}
//#ifndef COMPANYDAO_H
//#define COMPANYDAO_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "time.h"
#include "company.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include "directmessagedao.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QStringList>
#include <QVector>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
     QString CompanyDAO::serializeVector(const QVector<QString>& v) {
    QString result;
    QByteArray buffer;
    QDataStream stream(&buffer, QIODevice::WriteOnly);
    stream << v;
    result = QString::fromUtf8(buffer.toBase64());
    return result;
   }

    QVector<QString> CompanyDAO::deserializeVector(const QString& s) {
    QByteArray buffer = QByteArray::fromBase64(s.toUtf8());
    QDataStream stream(&buffer, QIODevice::ReadOnly);
    QVector<QString> result;
    stream >> result;
    return result;
    }

     bool CompanyDAO::saveCompany(company& c) {
        QSqlQuery query;
        query.prepare("INSERT INTO company (Company_ID, Company_Name, Employees, Followers, Company_Jobs) VALUES (?, ?, ?, ?, ?)");
        query.addBindValue(c.Account_ID);
        query.addBindValue(c.Company_name);
        query.addBindValue(serializeVector(c.Employee));
        query.addBindValue(serializeVector(c.following));
        query.addBindValue(serializeVector(c.Company_Jobs));
        if (!query.exec()) {
            qDebug() << "Error saving company:" << query.lastError().text();
            return false;
        }
        return true;
    }

     QVector<company> CompanyDAO::getAllCompanies() {
        QVector<company> companies;
        QSqlQuery query("SELECT * FROM company");
        while (query.next()) {
            company c;
            c.Account_ID = query.value(0).toString();
            c.Company_name = query.value(1).toString();
            c.Employee = deserializeVector(query.value(2).toString());
            c.following = deserializeVector(query.value(3).toString());
            c.Company_Jobs = deserializeVector(query.value(4).toString());
            companies.append(c);
        }
        return companies;
    }

     QVector<company> CompanyDAO::getCompaniesByJob(const QString& job_name) {
         QVector<company> companies;
         QVector<company> all_companies = getAllCompanies();
         for (const auto& c : all_companies) {
             if (c.Company_Jobs.contains(job_name)) {
                 companies.append(c);
             }
         }
         return companies;
     }

     bool CompanyDAO::isAccountInCompanyTable(const QString& account_id) {
         QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
         db.setDatabaseName("d:\\posts.db");

         if (!db.open()) {
             qDebug() << "Error opening database connection:" << db.lastError().text();
             return false;
         }

         QSqlQuery query;
         query.prepare("SELECT COUNT(*) FROM company WHERE Account_id = :account_id");
         query.bindValue(":account_id", account_id);

         if (!query.exec()) {
             qDebug() << "Error executing SQL query:" << query.lastError().text();
             db.close();
             return false;
         }

         if (query.next() && query.value(0).toInt() > 0) {
             db.close();
             return true;
         } else {
             db.close();
             return false;
         }
     }

     company CompanyDAO::getCompanyByAccountID(const QString& accountID) {
         company c;
         QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
         db.setDatabaseName("d:\\posts.db");

         if (!db.open()) {
             qDebug() << "Error opening database connection:" << db.lastError().text();
             return c;
         }

         QSqlQuery query;
         query.prepare("SELECT * FROM companies WHERE Account_ID = :accountID");
         query.bindValue(":accountID", accountID);

         if (!query.exec()) {
             qDebug() << "Error executing SQL query:" << query.lastError().text();
             db.close();
             return c;
         }

         if (query.next()) {
             c.Account_ID = query.value(0).toString();
             c.Company_name = query.value(1).toString();
             c.Employee = deserializeVector(query.value(2).toString());
             c.following = deserializeVector(query.value(3).toString());
             c.Company_Jobs = deserializeVector(query.value(4).toString());
         }

         db.close();
         return c;
     }

     QVector<QString> CompanyDAO::getCompanyFollowersByAccountID(const QString& accountID) {
         QVector<QString> followers;
         QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
         db.setDatabaseName("d:\\posts.db.db");

         if (!db.open()) {
             qDebug() << "Error opening database connection:" << db.lastError().text();
             return followers;
         }

         QSqlQuery query;
         query.prepare("SELECT Followers FROM company WHERE Account_id = :accountID");
         query.bindValue(":accountID", accountID);

         if (!query.exec()) {
             qDebug() << "Error executing SQL query:" << query.lastError().text();
             db.close();
             return followers;
         }

         if (query.next()) {
             QString followersString = query.value(0).toString();
             followers = deserializeVector(followersString);
         }

         db.close();
         return followers;
     }

     bool CompanyDAO::AddEmployee(const QString& accountID,const QString& company_name1){
         QVector<QString> employe;
         QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
         db.setDatabaseName("d:\\posts.db.db");

         QSqlQuery query;
         query.prepare("SELECT Employee FROM company WHERE company_name = :ID");
         query.bindValue(":ID", company_name1);

         QString empString = query.value(0).toString();
         employe = deserializeVector(empString);
         employe.push_back(accountID);

         query.prepare("UPDATE company WHERE Company_Name = :companyName SET Employees = :employees") ;
         query.bindValue(":companyName", company_name1) ;
         query.bindValue(":employees", serializeVector(employe)) ;
         return true;

     }

     QString CompanyDAO::getCompanyIDByName(const QString& companyName) {
         QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
         db.setDatabaseName("d:\\posts.db");

         if (!db.open()) {
             qDebug() << "Error opening database connection:" << db.lastError().text();
             return QString();
         }

         QSqlQuery query;
         query.prepare("SELECT id FROM companies WHERE Company_name = :companyName");
         query.bindValue(":companyName", companyName);

         if (!query.exec()) {
             qDebug() << "Error executing SQL query:" << query.lastError().text();
             db.close();
             return QString();
         }

         if (query.next()) {
             QString companyID = query.value(0).toString();
             db.close();
             return companyID;
         } else {
             qDebug() << "No company found with the name:" << companyName;
             db.close();
             return QString();
         }
     }

     bool CompanyDAO::Addfollower(const QString& accountID,const QString& company_name1){
         QVector<QString> followers;
         QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
         db.setDatabaseName("d:\\posts.db.db");

         QSqlQuery query;
         query.prepare("SELECT Followers FROM company WHERE company_name = :ID");
         query.bindValue(":ID", company_name1);

         QString followersString = query.value(0).toString();
         followers = deserializeVector(followersString);
         followers.push_back(accountID);

         query.prepare("UPDATE company WHERE Company_Name = :companyName SET followers = :fol") ;
         query.bindValue(":companyName", company_name1) ;
         query.bindValue(":fol", serializeVector(followers)) ;
         return true;

     }

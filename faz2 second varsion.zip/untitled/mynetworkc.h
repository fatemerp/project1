#ifndef MYNETWORKC_H
#define MYNETWORKC_H

#include <QMainWindow>

namespace Ui {
class mynetworkC;
}

class mynetworkC : public QMainWindow
{
    Q_OBJECT

public:
    explicit mynetworkC(QWidget *parent = nullptr);
    ~mynetworkC();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::mynetworkC *ui;
};

#endif // MYNETWORKC_H

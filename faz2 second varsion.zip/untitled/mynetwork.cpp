
#include "mynetwork.h"
#include "ui_mynetwork.h"
#include "home.h"
#include "jobs.h"
#include "massaging.h"
#include "me.h"
#include <ctime>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "accountdao.h"
#include <QSqlError>
#include <QDebug>
#include "jobdao.h"
#include "job.h"
#include "person.h"
#include "persondao.h"
#include "company.h"
#include "companydao.h"
#include "jobsc.h"
#include "mynetworkc.h"
#include "notification.h"
QString myid;
QVector<person>suggest1;
QVector<person>suggest2;
std::vector<QString>req;
person sug1;
person sug2;
person sug3;
person sug4;
QString req1;
QString req2;
QString req3;
QString req4;
myNetwork::myNetwork(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::myNetwork)
{
    ui->setupUi(this);

    QSqlQuery query;
QString id;
    if (query.exec("SELECT name FROM user")) {
        while (query.next()) {
            id = query.value(0).toString();
            break; // just first one
            myid=id;
        }
    } else {
        qDebug() << "Failed to retrieve sender_id:" << query.lastError().text();
    }

    QString my_job;
    query.prepare("SELECT job FROM persons WHERE Account_ID = :account_id");
    query.bindValue(":account_id", id);
    if (query.exec()) {
        if (query.next()) {
            my_job = query.value(0).toString();
            suggest1 = PersonDAO::getPersonsByJob(my_job);

        }
    } else {
        qDebug() << "Failed to retrieve job:" << query.lastError().text();
    }
    if (!suggest1.isEmpty()) {
         sug1 = suggest1.back();
        suggest1.pop_back();
        QString a1=sug1.Account_ID;
        QString a2="you two do same job";
        ui->label_9->setText(a1);
        ui->label_10->setText(a2);
    }
    if (!suggest1.isEmpty()) {
         sug2 = suggest1.back();
        suggest1.pop_back();
        QString a1=sug2.Account_ID;
        QString a2="you two do same job";
        ui->label_11->setText(a1);
        ui->label_12->setText(a2);

    }
    if (!suggest1.isEmpty()) {
         sug3 = suggest1.back();
        suggest1.pop_back();
        QString a1=sug3.Account_ID;
        QString a2="you two do same job";
        ui->label_13->setText(a1);
        ui->label_14->setText(a2);

    }
    if (!suggest1.isEmpty()) {
         sug4 = suggest1.back();
        suggest1.pop_back();
        QString a1=sug4.Account_ID;
        QString a2="you two do same job";
        ui->label_15->setText(a1);
        ui->label_16->setText(a2);

    }

    req=myNetwork::getFromByTo(myid);

    if (!req.empty()) {
         req1 = req.back();
        req.pop_back();
        ui->label_3->setText(req1);

    }
    if (!req.empty()) {
         req2 = req.back();
        req.pop_back();
        ui->label_6->setText(req2);

    }
    if (!req.empty()) {
         req3 = req.back();
        req.pop_back();
        ui->label_7->setText(req3);

    }
    if (!req.empty()) {
         req4 = req.back();
        req.pop_back();
        ui->label_8->setText(req4);

    }
}

myNetwork::~myNetwork()
{
    delete ui;
}


void myNetwork::on_pushButton_clicked()
{
   home *mtr =new home;
    mtr-> setWindowTitle("home");
    mtr-> show();
}


void myNetwork::on_pushButton_2_clicked()
{
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
}


void myNetwork::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void myNetwork::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}

void myNetwork::on_pushButton_6_clicked()
{
    QString to= sug1.Account_ID ;
    myNetwork::insertRequest(myid,to);
    QString tx = myid+"  has live a request to get in conection with you";
    notification::saveInformation(to,tx);

}


void myNetwork::insertRequest(const QString& from, const QString& to) {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\posts.db");

    if (!db.open()) {
        qDebug() << "Error opening database:" << db.lastError().text();
        return;
    }


    QSqlQuery query;
    query.prepare("INSERT INTO requests (from, to) VALUES (:from, :to)");
    query.bindValue(":from", from);
    query.bindValue(":to", to);


    if (!query.exec()) {
        qDebug() << "Error executing query:" << query.lastError().text();
    } else {
        qDebug() << "Request inserted successfully.";
    }
    db.close();
}

std::vector<QString> myNetwork::getFromByTo(const QString& to) {
    std::vector<QString> result;


    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\posts.db");
    if (!db.open()) {
        return result;
    }

    QSqlQuery query;
    query.prepare("SELECT from FROM requests WHERE to = :to");
    query.bindValue(":to", to);

    if (query.exec()) {
        while (query.next()) {
            result.push_back(query.value(0).toString());
        }
    }

    db.close();

    return result;
}


void myNetwork::on_pushButton_8_clicked()
{


}


void myNetwork::on_pushButton_9_clicked()
{

    QString to= sug3.Account_ID ;
    myNetwork::insertRequest(myid,to);
    QString tx = myid+"  has live a request to get in conection with you";
    notification::saveInformation(to,tx);
}


void myNetwork::on_pushButton_10_clicked()
{

    QString to= sug4.Account_ID ;
    myNetwork::insertRequest(myid,to);
    QString tx = myid+"  has live a request to get in conection with you";
    notification::saveInformation(to,tx);
}

void myNetwork::deleteRequest(const QString& from, const QString& to) {

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\posts.db");
    if (!db.open()) {
        return;
    }

    QSqlQuery query;
    query.prepare("DELETE FROM requests WHERE from = :from AND to = :to");
    query.bindValue(":from", from);
    query.bindValue(":to", to);


    if (!query.exec()) {
        qDebug() << "Error executing query:" << query.lastError().text();
    }


    db.close();
}

void myNetwork::on_pushButton_13_clicked()
{

}


void myNetwork::on_pushButton_7_clicked()
{
    QString to= sug2.Account_ID ;
    myNetwork::insertRequest(myid,to);
    QString tx = myid+"  has live a request to get in conection with you";
    notification::saveInformation(to,tx);
}


void myNetwork::on_pushButton_11_clicked()
{
    accountDAO::addConnection(req1,myid);
    myNetwork::deleteRequest(req1,myid);
    QString tx = myid+"  has accept your request to get in conection ";
    notification::saveInformation(req1,tx);
}


void myNetwork::on_pushButton_12_clicked()
{
    myNetwork::deleteRequest(req1,myid);
    QString tx = myid+"  has ignore your request to get in conection ";
    notification::saveInformation(req1,tx);
}


void myNetwork::on_pushButton_15_clicked()
{accountDAO::addConnection(req2,myid);
    myNetwork::deleteRequest(req2,myid);
    QString tx = myid+"  has accept your request to get in conection ";
    notification::saveInformation(req2,tx);
}


void myNetwork::on_pushButton_16_clicked()
{
    myNetwork::deleteRequest(req2,myid);
    QString tx = myid+"  has ignore your request to get in conection ";
    notification::saveInformation(req2,tx);
}


void myNetwork::on_pushButton_17_clicked()
{accountDAO::addConnection(req3,myid);
    myNetwork::deleteRequest(req3,myid);
    QString tx = myid+"  has accept your request to get in conection ";
    notification::saveInformation(req3,tx);
}


void myNetwork::on_pushButton_18_clicked()
{
    myNetwork::deleteRequest(req3,myid);
    QString tx = myid+"  has ignore your request to get in conection ";
    notification::saveInformation(req3,tx);
}


void myNetwork::on_pushButton_19_clicked()
{accountDAO::addConnection(req4,myid);
    myNetwork::deleteRequest(req4,myid);
    QString tx = myid+"  has accept your request to get in conection ";
    notification::saveInformation(req4,tx);
}


void myNetwork::on_pushButton_20_clicked()
{
    myNetwork::deleteRequest(req4,myid);
    QString tx = myid+"  has ignore your request to get in conection ";
    notification::saveInformation(req4,tx);
}


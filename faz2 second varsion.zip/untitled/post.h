#ifndef POST_H
#define POST_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include "content.h"
#include "like.h"
#include "comment.h"
#include <ctime>

class post  : public content
{
public:
post();
QString Post_ID;
int Reposet_counter;
QVector<like*> Likes;
QVector<comment*> Comments;
};

#endif // POST_H

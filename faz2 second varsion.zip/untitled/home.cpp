
#include "home.h"
#include "ui_home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "massaging.h"
#include "me.h"
#include "content.h"
#include "post.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "postdao.h"
#include "start_post.h"
#include <ctime>
#include "postdao.h"
#include <QApplication>
#include <QLabel>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVBoxLayout>
#include <QWidget>
#include <accountdao.h>
#include "jobsc.h"
#include "mynetworkc.h"
#include "companydao.h"
#include "company.h"
#include "person.h"
#include "persondao.h"
#include "jobsc.h"
#include "mynetworkc.h"
#include "account.h"
#include "accountdao.h"
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "comment.h"
#include "commentdao.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <ctime>
#include "likedao.h"
#include "notification.h"
QString comment1;
int t1;
int a=-9;
QVector<post*> posts;
post* post10;
post* post9;
post* post8;
post* post7;
post* post6;
post* post5;
post* post4;
post* post3;
post* post2;
post* post1;
QString id1;

home::home(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::home)
{
    ui->setupUi(this);
    ///
    ui->groupBox_30->hide();
    ui->scrollArea_2->hide();
    ui->groupBox_31->hide();
    QSqlQuery query;
     QString id;
     id=query.exec("SELECT name FROM user ");
    id1=id;
    //get posts of followings:
    QString* following = new QString[20];
    following= accountDAO::getAccountFollowing(id);

    for (int i = 0; following[i] != nullptr; i++) {
        QString followedId = following[i];
        posts.append(PostDAO::getPostBySenderId(followedId));//like push_back but for string and zanciri
        delete[] following;
    }

    if (query.exec("SELECT type FROM user")) {//to feager it account company
        while (query.next()) {
            t1 = query.value(0).toInt();
            break; // just first one
        }
    }
    on_pushButton_6_clicked();//first time show posts
}

home::~home()
{
    delete ui;

}




void home::on_pushButton_clicked()
{
    if(t1==1){
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();}
    else if (t1==0){
        mynetworkC *mtr1 =new mynetworkC;
         mtr1-> setWindowTitle("myNetworkc");
         mtr1-> show();
    }
}


void home::on_pushButton_2_clicked()
{
    if(t1==1){
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
    }
    else if (t1==0){
        jobsC *mtr1 =new jobsC;
         mtr1-> setWindowTitle("myNetworkc");
         mtr1-> show();}
}


void home::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void home::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


void home::on_pushButton_5_clicked()//search box:
{
    ui->scrollArea_2->show();
    QString a=ui-> lineEdit ->text();
    std::vector< QString >search = accountDAO::getAccountIDsByPartialID(a);
    if (!search.empty()) {
        QString s1 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_4->setText(coid);
        ui->label_5->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_4->setText(coid);
            ui->label_5->setText(name);
        }
    }

    if (!search.empty()) {
        QString s2 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s2)){
        company co1=CompanyDAO::getCompanyByAccountID(s2);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_6->setText(coid);
        ui->label_7->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s2);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_6->setText(coid);
            ui->label_7->setText(name);
        }
    }

    if (!search.empty()) {
        QString s3 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s3)){
        company co1=CompanyDAO::getCompanyByAccountID(s3);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_8->setText(coid);
        ui->label_9->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s3);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_8->setText(coid);
            ui->label_9->setText(name);
        }
    }

    if (!search.empty()) {
        QString s4 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s4)){
        company co1=CompanyDAO::getCompanyByAccountID(s4);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_10->setText(coid);
        ui->label_11->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s4);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_10->setText(coid);
            ui->label_11->setText(name);
        }
    }

}


void home::on_pushButton_6_clicked()
{
    start_post *str =new start_post;
     str-> setWindowTitle("start_post");
     str-> show();
}


void home::on_pushButton_7_clicked()//show more posts:
{

    if (!posts.isEmpty()) {
         post1 = posts.back();
        posts.pop_back();

        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_12->setText(i);
        ui->label_13->setText(t);

         }
    if (!posts.isEmpty()) {
         post2 = posts.back();
        posts.pop_back();

        QString i=post2->sender_ID;
        QString t=post2->Content_Text;
        ui->label_14->setText(i);
        ui->label_15->setText(t);
         }
    if (!posts.isEmpty()) {
         post3 = posts.back();
        posts.pop_back();

        QString i=post3->sender_ID;
        QString t=post3->Content_Text;
        ui->label_16->setText(i);
        ui->label_17->setText(t);
         }
    if (!posts.isEmpty()) {
         post4 = posts.back();
        posts.pop_back();

        QString i=post4->sender_ID;
        QString t=post4->Content_Text;
        ui->label_18->setText(i);
        ui->label_19->setText(t);
         }
    if (!posts.isEmpty()) {
         post5 = posts.back();
        posts.pop_back();

        QString i=post5->sender_ID;
        QString t=post5->Content_Text;
        ui->label_20->setText(i);
        ui->label_21->setText(t);
         }
    if (!posts.isEmpty()) {
         post6 = posts.back();
        posts.pop_back();

        QString i=post6->sender_ID;
        QString t=post6->Content_Text;
        ui->label_22->setText(i);
        ui->label_23->setText(t);
         }
    if (!posts.isEmpty()) {
         post7 = posts.back();
        posts.pop_back();

        QString i=post7->sender_ID;
        QString t=post7->Content_Text;
        ui->label_24->setText(i);
        ui->label_25->setText(t);
         }
    if (!posts.isEmpty()) {
         post8 = posts.back();
        posts.pop_back();

        QString i=post8->sender_ID;
        QString t=post8->Content_Text;
        ui->label_26->setText(i);
        ui->label_27->setText(t);
         }
    if (!posts.isEmpty()) {
         post9 = posts.back();
        posts.pop_back();

        QString i=post9->sender_ID;
        QString t=post9->Content_Text;
        ui->label_28->setText(i);
        ui->label_29->setText(t);
         }
    if (!posts.isEmpty()) {
         post10 = posts.back();
        posts.pop_back();

        QString i=post10->sender_ID;
        QString t=post10->Content_Text;
        ui->label_30->setText(i);
        ui->label_31->setText(t);
         }




}


//follow:
void home::on_pushButton_11_clicked()
{
    QString id2= post1->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_15_clicked()
{
    QString id2= post2->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_20_clicked()
{
    QString id2= post3->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_25_clicked()
{
    QString id2= post4->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_35_clicked()
{
    QString id2= post5->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_40_clicked()
{
    QString id2= post6->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_50_clicked()
{
    QString id2= post7->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_60_clicked()
{
    QString id2= post8->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_65_clicked()
{
    QString id2= post9->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}


void home::on_pushButton_70_clicked()
{
    QString id2= post10->sender_ID;
    if(CompanyDAO::isAccountInCompanyTable(id2)){
    QVector<QString> fid;
    fid.push_back(id2);
    accountDAO::saveAccountFollowing(id1,fid);
    company com=CompanyDAO::getCompanyByAccountID(id2);
    CompanyDAO::Addfollower(id1,com.Company_name);
    QString tx = id1+"  start following you";
    notification::saveInformation(id2,tx);
    }
    else{

        myNetwork::insertRequest(id1,id2);
        QString tx = id1+"  has live a request to get in conection with you";
        notification::saveInformation(id2,tx);
    }
}

//repost:
void home::on_pushButton_10_clicked()
{
    post* newpost=post1;
    newpost->sender_ID=id1;
    newpost->Content_Text=post1->Content_Text+" "+"#reposted";
    post1->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post1->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_14_clicked()
{
    post* newpost=post2;
    newpost->sender_ID=id1;
    newpost->Content_Text=post2->Content_Text+" "+"#reposted";
    post2->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post2->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_19_clicked()
{
    post* newpost=post3;
    newpost->sender_ID=id1;
    newpost->Content_Text=post3->Content_Text+" "+"#reposted";
    post3->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post3->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_24_clicked()
{
    post* newpost=post4;
    newpost->sender_ID=id1;
    newpost->Content_Text=post4->Content_Text+" "+"#reposted";
    post4->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post4->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_34_clicked()
{
    post* newpost=post5;
    newpost->sender_ID=id1;
    newpost->Content_Text=post5->Content_Text+" "+"#reposted";
    post5->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post5->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_39_clicked()
{
    post* newpost=post6;
    newpost->sender_ID=id1;
    newpost->Content_Text=post6->Content_Text+" "+"#reposted";
    post6->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post6->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_49_clicked()
{
    post* newpost=post7;
    newpost->sender_ID=id1;
    newpost->Content_Text=post7->Content_Text+" "+"#reposted";
    post7->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post7->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_59_clicked()
{
    post* newpost=post8;
    newpost->sender_ID=id1;
    newpost->Content_Text=post8->Content_Text+" "+"#reposted";
    post8->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post8->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_64_clicked()
{
    post* newpost=post9;
    newpost->sender_ID=id1;
    newpost->Content_Text=post9->Content_Text+" "+"#reposted";
    post9->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post9->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_69_clicked()
{
    post* newpost=post10;
    newpost->sender_ID=id1;
    newpost->Content_Text=post10->Content_Text+" "+"#reposted";
    post10->Reposet_counter+=1;
    PostDAO::savePost(*newpost);
    QString ci= post10->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}

//like:
void home::on_pushButton_8_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post1->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post1->sender_ID;
    QString tx = id1+"  has like your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_16_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post2->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post2->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_21_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post3->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post3->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_26_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post4->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post4->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_36_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post5->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post5->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_41_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post6->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post6->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_51_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post7->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post7->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_61_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post8->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post8->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_66_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post9->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post9->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_71_clicked()
{
    like like1;
    like1.Time=QDateTime::currentDateTime();
    std::string a = post10->Post_ID.toStdString();
    like1.post_id = std::stoi(a);
    like1.Who_liked_ID=id1;
    LikeDAO::createLike(like1);
    QString ci= post10->sender_ID;
    QString tx = id1+"  has repost your post";
    notification::saveInformation(ci,tx);
}

//comment:
void home::on_pushButton_28_clicked()
{
    comment1 =ui-> lineEdit_2 ->text();
    ui->groupBox_30->hide();
}


void home::on_pushButton_9_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post1->Post_ID;
    CommentDAO::createComment(com1);
    //
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post1->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }
    QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_13_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post2->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post2->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_18_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post3->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post3->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_23_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post4->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post4->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_33_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post5->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post5->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_38_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post6->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post6->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_48_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post7->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post7->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_58_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post8->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post8->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_63_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post9->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post9->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_68_clicked()
{
    ui->groupBox_30->show();
    comment com1;
    com1.Time_sent=QDateTime::currentDateTime();
    com1.sender_ID=id1;
    com1.Content_Text=comment1;
    com1.Post_ID=post10->Post_ID;
    CommentDAO::createComment(com1);
    QVector<comment> coco;
    coco = CommentDAO::getCommentsByPostID(post10->Post_ID);
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_32->setText(i);
        ui->label_33->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_34->setText(i);
        ui->label_35->setText(t);
         }
    if (!coco.isEmpty()) {
        comment cc1;
         cc1 = coco.back();
        coco.pop_back();
        QString i=cc1.sender_ID;
        QString t=cc1.Content_Text;
        ui->label_36->setText(i);
        ui->label_37->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);
}


void home::on_pushButton_12_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post1->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }QString ci= post1->sender_ID;
    QString tx = id1+"  leave an comment on your post";
    notification::saveInformation(ci,tx);

}


void home::on_pushButton_29_clicked()
{
    ui->groupBox_31->hide();
}


void home::on_pushButton_17_clicked()//show likes:
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post2->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_22_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post3->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_27_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post4->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_37_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post5->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_42_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post6->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_52_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post7->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_62_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post8->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_67_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post9->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


void home::on_pushButton_72_clicked()
{
    ui->groupBox_31->show();
    QVector<like> li;
    li = LikeDAO::getLikesByPostID(post10->Post_ID);
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_38->setText(i);
        ui->label_39->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_40->setText(i);
        ui->label_41->setText(t);
         }
    if (!li.isEmpty()) {
        like l1;
         l1 = li.back();
        li.pop_back();
        QString i=l1.Who_liked_ID;
        QString t=l1.Time.toString();
        ui->label_42->setText(i);
        ui->label_43->setText(t);
         }

}


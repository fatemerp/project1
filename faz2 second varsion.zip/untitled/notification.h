#ifndef NOTIFICATION_H
#define NOTIFICATION_H

#include <QMainWindow>

namespace Ui {
class notification;
}

class notification : public QMainWindow
{
    Q_OBJECT

public:
    explicit notification(QWidget *parent = nullptr);
    ~notification();

    static bool  saveInformation(const QString& , const QString& ) ;

    static QVector<QString> getInformation(const QString& );

private slots:
    void on_pushButton_clicked();

private:
    Ui::notification *ui;
};

#endif // NOTIFICATION_H

#include "start_job.h"
#include "ui_start_job.h"
#include "job.h"
#include "jobdao.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "companydao.h"
#include "company.h"
#include "person.h"
#include "persondao.h"

start_job::start_job(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::start_job)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    //dark mood:
    QSqlQuery query;
    int color;
     query.exec("SELECT dm FROM darkmood ")   ;
     color=query.value(0).toInt();
     // white back ground
        if (color==0)start_job::setStyleSheet("background-color: rgb(234, 234, 234)");
     //gray back ground
       else if (color==1)  start_job::setStyleSheet("background-color: rgb(79, 79, 79)");

}

start_job::~start_job()
{
    delete ui;
}

void start_job::on_pushButton_clicked()
{
 job j1;
 QSqlQuery query;
 QString id;
 id= query.exec("SELECT name FROM user ")   ;
 company me=CompanyDAO::getCompanyByAccountID(id);
         QString a2=me.Company_name;
 j1.Company_name=a2;
 j1.job_name=ui->lineEdit->text();
 j1.workPlace_type=ui->lineEdit_2->text();
 j1.location=ui->lineEdit_3->text();
 j1.type=ui->lineEdit_5->text();
 JobDAO::createJob(j1);
}


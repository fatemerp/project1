#include "apply_job.h"

apply_job::apply_job()
{

}
QVector<apply_job*> apply_job::getJobApplicationsByCompanyName(const QString& companyName) {
    QVector<apply_job*> applications;
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\posts.db"); // Replace with the actual name of your database file

    if (!db.open()) {
        qDebug() << "Error opening database connection:" << db.lastError().text();
        return applications;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM apply_job WHERE Company_Name = :companyName");
    query.bindValue(":companyName", companyName);

    if (!query.exec()) {
        qDebug() << "Error executing SQL query:" << query.lastError().text();
        db.close();
        return applications;
    }

    while (query.next()) {
        apply_job* app = new apply_job();
        app->company_name = query.value(0).toString();
        app->job_name = query.value(1).toString();
        app->sender_id = query.value(2).toString();
        app->v = query.value(3).toInt();
        applications.append(app);
    }

    db.close();
    return applications;
}


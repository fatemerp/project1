#include "notification.h"
#include "ui_notification.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "companydao.h"
#include "company.h"
#include "person.h"
#include "persondao.h"
#include "me.h"
QString idn;
QVector <QString> notif;
notification::notification(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::notification)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    //dark mood:
    QSqlQuery query;
    int color;
     query.exec("SELECT dm FROM darkmood ")   ;
     color=query.value(0).toInt();
     // white back ground
        if (color==0) notification::setStyleSheet("background-color: rgb(234, 234, 234)");
     //gray back ground
       else if (color==1)  notification::setStyleSheet("background-color: rgb(79, 79, 79)");

    if (query.exec("SELECT name FROM user")) {
        while (query.next()) {
            idn = query.value(0).toString();
            break; // just first one

        }
    } else {
        qDebug() << "Failed to retrieve sender_id:" << query.lastError().text();
    }
    notif=notification::getInformation(idn);
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label->setText(n1);
    }
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label_2->setText(n1);
    }
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label_3->setText(n1);
    }
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label_4->setText(n1);
    }
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label_5->setText(n1);
    }
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label_6->setText(n1);
    }
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label_7->setText(n1);
    }
    if (!notif.isEmpty()) {
         QString n1 = notif.back();
        notif.pop_back();
        ui->label_8->setText(n1);
    }

}

notification::~notification()
{
    delete ui;
}


    bool notification::saveInformation(const QString& id, const QString& text) {
        QSqlDatabase db = QSqlDatabase::database();
        QSqlQuery query(db);

        query.prepare("INSERT INTO notification (id, text) VALUES (:id, :text)");
        query.bindValue(":id", id);
        query.bindValue(":text", text);

        if (!query.exec()) {
            qDebug() << "Error executing SQL query:" << query.lastError().text();
            return false;
        }

        return true;
    }


    QVector<QString> notification::getInformation(const QString& id) {
        QSqlDatabase db = QSqlDatabase::database();
        QSqlQuery query(db);

        query.prepare("SELECT text FROM notification WHERE id = :id");
        query.bindValue(":id", id);

        if (!query.exec()) {
            qDebug() << "Error executing SQL query:" << query.lastError().text();
            return QVector<QString>();
        }

        QVector<QString> texts;
        while (query.next()) {
            texts.append(query.value(0).toString());
        }

        return texts;
    }


void notification::on_pushButton_clicked()//back to me
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


#ifndef COMPANYDAO_H
#define COMPANYDAO_H
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "account.h"
#include "comment.h"
#include "post.h"
#include "directmassage.h"
#include "postdao.h"
#include "company.h"
#include "directmassage.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QStringList>
#include <QVector>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
#include <ctime>

class CompanyDAO {
public:
static bool saveCompany(company&  ) ;

static QVector<company> getAllCompanies() ;
static QVector<company> getCompaniesByJob(const QString& );
 static bool isAccountInCompanyTable(const QString& );
 static company getCompanyByAccountID(const QString& );
 static QVector<QString> getCompanyFollowersByAccountID(const QString& ) ;
 static QString getCompanyIDByName(const QString& companyName);
 static bool AddEmployee(const QString& ,const QString&);
 static bool Addfollower(const QString& ,const QString& );
private:
static QString serializeVector(const QVector<QString>&  ) ;

static QVector<QString> deserializeVector(const QString&  ) ;

};


#endif // COMPANYDAO_H

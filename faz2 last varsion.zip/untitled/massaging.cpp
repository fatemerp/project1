
#include "massaging.h"
#include "ui_massaging.h"
#include "home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "me.h"
#include <ctime>
#include <qdebug.h>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "directmessagedao.h"
#include "person.h"
#include "persondao.h"
#include "p1.h"

#include "jobsc.h"
#include "mynetworkc.h"
QVector <QString> intouch;

person pp1;
person pp2;
person pp3;
person pp4;
person pp5;
QString person1,person2,person3,person4,person5;

massaging::massaging(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::massaging)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    //dark mood:
    QSqlQuery query;
    int color;
     query.exec("SELECT dm FROM darkmood ")   ;
     color=query.value(0).toInt();
     // white back ground
        if (color==0) massaging::setStyleSheet("background-color: rgb(234, 234, 234)");
     //gray back ground
       else if (color==1)  massaging::setStyleSheet("background-color: rgb(79, 79, 79)");

    QString id;
    if (query.exec("SELECT name FROM user")) {
        while (query.next()) {
            id = query.value(0).toString();
            break; // just 1th
        }
        std::vector<QString> accountIDs = DirectMessageDAO::getAccountIDsWithDirectMessages(id);
        for (const auto& accountID : accountIDs) {
            intouch.append(accountID);
        }
        if (!intouch.isEmpty()) {
             person1 = intouch.back();
            intouch.pop_back();
            pp1=PersonDAO::getPersonByAccountId(person1);
            QString a1 =pp1.Account_ID;
            QString a2=pp1.First_Name+" "+pp1.Last_Name;
                  ui->label_3->setText(a1);
                  ui->label_4->setText(a2);

             }
        if (!intouch.isEmpty()) {
             person2 = intouch.back();
            intouch.pop_back();
             pp2=PersonDAO::getPersonByAccountId(person2);
             QString a1 =pp2.Account_ID;
             QString a2=pp2.First_Name+" "+pp2.Last_Name;
                   ui->label_5->setText(a1);
                   ui->label_6->setText(a2);

             }
        if (!intouch.isEmpty()) {
             person3 = intouch.back();
            intouch.pop_back();
            pp3=PersonDAO::getPersonByAccountId(person3);
            QString a1 =pp3.Account_ID;
            QString a2=pp3.First_Name+" "+pp3.Last_Name;
                  ui->label_7->setText(a1);
                  ui->label_8->setText(a2);
             }
        if (!intouch.isEmpty()) {
             person4 = intouch.back();
            intouch.pop_back();
            pp4=PersonDAO::getPersonByAccountId(person4);
            QString a1 =pp4.Account_ID;
            QString a2=pp4.First_Name+" "+pp4.Last_Name;
                  ui->label_9->setText(a1);
                  ui->label_10->setText(a2);

             }
        if (!intouch.isEmpty()) {
             person5 = intouch.back();
            intouch.pop_back();
            pp5=PersonDAO::getPersonByAccountId(person5);
            QString a1 =pp5.Account_ID;
            QString a2=pp5.First_Name+" "+pp5.Last_Name;
                  ui->label_11->setText(a1);
                  ui->label_12->setText(a2);

             }
    }
}

massaging::~massaging()
{
    delete ui;
}


void massaging::on_pushButton_clicked()
{
    int t;
    QSqlQuery query;
        if (query.exec("SELECT type FROM user")) {
            while (query.next()) {
                t = query.value(0).toInt();
                break; // just first one
            }
        }

        if(t==1){
       myNetwork *mtr =new myNetwork;
        mtr-> setWindowTitle("myNetwork");
        mtr-> show();}
        else if (t==0){
            mynetworkC *mtr1 =new mynetworkC;
             mtr1-> setWindowTitle("myNetworkc");
             mtr1-> show();
        }

}


void massaging::on_pushButton_2_clicked()
{
    int t;
    QSqlQuery query;
        if (query.exec("SELECT type FROM user")) {
            while (query.next()) {
                t = query.value(0).toInt();
                break; // just first one
            }
        }

    if(t==1){
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
    }
    else if (t==0){
        jobsC *mtr1 =new jobsC;
         mtr1-> setWindowTitle("myNetworkc");
         mtr1-> show();}
}


void massaging::on_pushButton_3_clicked()
{
    home *mstr =new home;
    mstr-> setWindowTitle("home");
    mstr-> show();
}


void massaging::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


void massaging::on_pushButton_6_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person1);
    p1 *mtr =new p1;
     mtr-> setWindowTitle("chats");
     mtr-> show();

}


void massaging::on_pushButton_7_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person2);
    p1 *mtr =new p1;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


void massaging::on_pushButton_8_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person3);
    p1 *mtr =new p1;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


void massaging::on_pushButton_9_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person4);
    p1 *mtr =new p1;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


void massaging::on_pushButton_10_clicked()
{
    QSqlQuery query;
    query.prepare("UPDATE lastdm SET id = :id");
    query.bindValue(":id", person5);
    p1 *mtr =new p1;
     mtr-> setWindowTitle("chats");
     mtr-> show();
}


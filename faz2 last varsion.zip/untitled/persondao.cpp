
#include "persondao.h"


#include <ctime>

#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>


     bool PersonDAO::createPerson(person& p) {
        QSqlQuery query;
        query.prepare("INSERT INTO persons (Account_ID, First_Name, Last_Name, Skills,job) VALUES (?, ?, ?, ?,?)");
        query.addBindValue(p.Account_ID);
        query.addBindValue(p.First_Name);
        query.addBindValue(p.Last_Name);
        query.addBindValue(serializeVector(p.Skills));
        query.addBindValue(p.Job);
        if (!query.exec()) {
            qDebug() << "Error creating person:" << query.lastError().text();
            return false;
        }
        return true;
    }

     QVector<person> PersonDAO::getAllPersons() {
        QVector<person> persons;
        QSqlQuery query("SELECT * FROM persons");
        while (query.next()) {
            person p;
            p.Account_ID = query.value(0).toString();
            p.First_Name = query.value(1).toString();
            p.Last_Name = query.value(2).toString();
            p.Skills = deserializeVector(query.value(3).toString());
            p.Job = query.value(4).toString();
            persons.append(p);
        }
        return persons;
    }

 QString PersonDAO::serializeVector(const QVector<QString>& v) {
        QString result;
        QByteArray buffer;
        QDataStream stream(&buffer, QIODevice::WriteOnly);
        stream << v;
        result = QString::fromUtf8(buffer.toBase64());
        return result;
    }

     QVector<QString> PersonDAO::deserializeVector(const QString& s) {
        QByteArray buffer = QByteArray::fromBase64(s.toUtf8());
        QDataStream stream(&buffer, QIODevice::ReadOnly);
        QVector<QString> result;
        stream >> result;
        return result;
    }

     person PersonDAO::getPersonByAccountId(const QString& account_id) {
         QSqlQuery query;
         query.prepare("SELECT * FROM persons WHERE Account_ID = :account_id");
         query.bindValue(":account_id", account_id);
         if (query.exec()) {

                 person p;
                 p.Account_ID = query.value(0).toString();
                 p.First_Name = query.value(1).toString();
                 p.Last_Name = query.value(2).toString();
                 p.Skills = deserializeVector(query.value(3).toString());
                 p.Job = query.value(4).toString();
                 return p;

         } else {
             qDebug() << "Failed to retrieve persons:" << query.lastError().text();
         }

     }

     QVector<person> PersonDAO::getPersonsByJob(const QString& job_name) {
         QVector<person> persons;
         QSqlQuery query;
         query.prepare("SELECT * FROM persons WHERE job = :job_name");
         query.bindValue(":job_name", job_name);
         if (query.exec()) {
             while (query.next()) {
                 person p;
                 p.Account_ID = query.value(0).toString();
                 p.First_Name = query.value(1).toString();
                 p.Last_Name = query.value(2).toString();
                 p.Skills = deserializeVector(query.value(3).toString());
                 p.Job = query.value(4).toString();
                 persons.append(p);
             }
         } else {
             qDebug() << "Failed to retrieve persons:" << query.lastError().text();
         }
         return persons;
     }



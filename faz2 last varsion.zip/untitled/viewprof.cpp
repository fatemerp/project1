#include "viewprof.h"
#include "ui_viewprof.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "companydao.h"
#include "company.h"
#include "person.h"
#include "persondao.h"
#include "notification.h"
#include "accountdao.h"
#include "mynetwork.h"
#include "me.h"
post* post11;
post* post21;
post* post31;
QString acid;
QString mid;
bool t3;
viewprof::viewprof(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::viewprof)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    QSqlQuery query;
    query.exec("SELECT id FROM viewprof ")   ;
    acid=query.value(0).toString();
    query.exec("SELECT name FROM user ")   ;
    mid=query.value(0).toString();
    query.exec("SELECT type FROM user ")   ;
    int t4;
    t4 =query.value(0).toInt();
    if(t4==0) t3=true;
    else t3=false;
    //dark mood:

    int color;
     query.exec("SELECT dm FROM darkmood ")   ;
     color=query.value(0).toInt();
     // white back ground
        if (color==0) viewprof::setStyleSheet("background-color: rgb(234, 234, 234)");
     //gray back ground
       else if (color==1)  viewprof::setStyleSheet("background-color: rgb(79, 79, 79)");

    ///
     t3=CompanyDAO::isAccountInCompanyTable(acid);
    if(t3==true){
         company me=CompanyDAO::getCompanyByAccountID(acid);
                 QString a1=me.Account_ID;
                 QString a2=me.Company_name;
                 QString a4=me.Phone_number;
                 QString a3=me.Email;
                 ui->label_3->setText(a1);
                 ui->label_4->setText(a2);
                 ui->label_6->setText(a4);
                 ui->label_8->setText(a3);

    }
    if(t3==false){
         person me =PersonDAO::getPersonByAccountId(acid);
               QString a1=me.Account_ID;
               QString a2=me.First_Name+" "+me.Last_Name;
               QString a3=me.Email;
               QString a4=PersonDAO::serializeVector( me.Skills) ;
               ui->label_3->setText(a1);
               ui->label_4->setText(a2);
               ui->label_6->setText(a3);
               ui->label_8->setText(a4);
    }
    QVector<post*> posts;
    posts.append( PostDAO::getPostBySenderId(acid));



    if (!posts.isEmpty()) {
         post11 = posts.back();
        posts.pop_back();

        QString i=post11->sender_ID;
        QString t=post11->Content_Text;
        ui->label_12->setText(i);
        ui->label_13->setText(t);

         }
    if (!posts.isEmpty()) {
         post21 = posts.back();
        posts.pop_back();

        QString i=post21->sender_ID;
        QString t=post21->Content_Text;
        ui->label_14->setText(i);
        ui->label_15->setText(t);
         }
    if (!posts.isEmpty()) {
         post31 = posts.back();
        posts.pop_back();

        QString i=post31->sender_ID;
        QString t=post31->Content_Text;
        ui->label_16->setText(i);
        ui->label_17->setText(t);
         }


}

viewprof::~viewprof()
{
    delete ui;
}

void viewprof::on_pushButton_20_clicked()//follow:
{
    if(t3==true){
    QVector<QString> fid;
    fid.push_back(acid);
    accountDAO::saveAccountFollowing(mid,fid);
    company com=CompanyDAO::getCompanyByAccountID(acid);
    CompanyDAO::Addfollower(mid,com.Company_name);
    QString tx = mid+"  start following you";
    notification::saveInformation(acid,tx);
    }
    else{

        myNetwork::insertRequest(mid,acid);
        QString tx = mid+"  has live a request to get in conection with you";
        notification::saveInformation(acid,tx);
    }
}


void viewprof::on_pushButton_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


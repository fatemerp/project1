#ifndef APPLY_JOB_H
#define APPLY_JOB_H
#include "jobs.h"
#include "ui_jobs.h"
#include "home.h"
#include "mynetwork.h"
#include "massaging.h"
#include "me.h"
#include <ctime>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
#include "jobdao.h"
#include "job.h"
#include "jobsc.h"
#include "mynetworkc.h"

class apply_job
{
public:
    apply_job();
    QString company_name;
    QString job_name;
    QString sender_id;
    int v;
    static QVector<apply_job*> getJobApplicationsByCompanyName(const QString&);
};

#endif // APPLY_JOB_H

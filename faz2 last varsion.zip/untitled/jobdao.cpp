
#include "jobdao.h"
#include <ctime>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>


      bool JobDAO::createJob(job& j) {
        QSqlQuery query;
        query.prepare("INSERT INTO jobs (job_name, Company_name, Skills_required, workPlace_type, location, type) VALUES (?, ?, ?, ?, ?, ?)");
        query.addBindValue(j.job_name);
        query.addBindValue(j.Company_name);
        query.addBindValue(serializeVector(j.Skills_required));
        query.addBindValue(j.workPlace_type);
        query.addBindValue(j.location);
        query.addBindValue(j.type);
        if (!query.exec()) {
            qDebug() << "Error creating job:" << query.lastError().text();
            return false;
        }
        return true;
    }

      QVector<job> JobDAO::getAllJobs() {
        QVector<job> jobs;
        QSqlQuery query("SELECT * FROM jobs");
        while (query.next()) {
            job j;
            j.job_name = query.value(0).toString();
            j.Company_name = query.value(1).toString();
            j.Skills_required = deserializeVector(query.value(2).toString());
            j.workPlace_type = query.value(3).toString();
            j.location = query.value(4).toString();
            j.type = query.value(5).toString();
            jobs.append(j);
        }
        return jobs;
    }

      QString JobDAO::serializeVector(const QVector<QString>& v) {
        QString result;
        QByteArray buffer;
        QDataStream stream(&buffer, QIODevice::WriteOnly);
        stream << v;
        result = QString::fromUtf8(buffer.toBase64());
        return result;
    }

      QVector<QString> JobDAO::deserializeVector(const QString& s) {
        QByteArray buffer = QByteArray::fromBase64(s.toUtf8());
        QDataStream stream(&buffer, QIODevice::ReadOnly);
        QVector<QString> result;
        stream >> result;
        return result;
    }

      QVector<job> JobDAO::getJobByName(const QString& job_name) {
          QVector<job> jobs;
          QSqlQuery query;
          query.prepare("SELECT * FROM jobs WHERE job_name = :job_name");
          query.bindValue(":job_name", job_name);
          if (query.exec()) {
              while (query.next()) {
                  job j;
                  j.job_name = query.value(0).toString();
                  j.Company_name = query.value(1).toString();
                  j.Skills_required = deserializeVector(query.value(2).toString());
                  j.workPlace_type = query.value(3).toString();
                  j.location = query.value(4).toString();
                  j.type = query.value(5).toString();
                  jobs.append(j);
              }
          } else {
              qDebug() << "Failed to retrieve jobs:" << query.lastError().text();
          }
          return jobs;
      }


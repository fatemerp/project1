#ifndef JOBSC_H
#define JOBSC_H

#include <QMainWindow>

namespace Ui {
class jobsC;
}

class jobsC : public QMainWindow
{
    Q_OBJECT

public:
    explicit jobsC(QWidget *parent = nullptr);
    ~jobsC();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_10_clicked();
    static bool setV(const QString& , const QString& , const QString& , int );

    void on_pushButton_11_clicked();

private:
    Ui::jobsC *ui;
};

#endif // JOBSC_H


#include "start_post.h"
#include "ui_start_post.h"
#include "postdao.h"
#include <ctime>
#include "post.h"
#include "content.h"
#include "home.h"

start_post::start_post(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::start_post)
{

    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    ui->setupUi(this);
    //dark mood:
    QSqlQuery query;
    int color;
     query.exec("SELECT dm FROM darkmood ")   ;
     color=query.value(0).toInt();
     // white back ground
        if (color==0)start_post::setStyleSheet("background-color: rgb(234, 234, 234)");
     //gray back ground
       else if (color==1)  start_post::setStyleSheet("background-color: rgb(79, 79, 79)");
}

start_post::~start_post()
{
    delete ui;
}



void start_post::on_pushButton_clicked()
{

QSqlQuery query;

    post post1;
    post1.sender_ID =query.exec("SELECT name FROM user ");

    post1.Content_Text= ui-> lineEdit ->text();

    int b;//to find post id
    query.exec("SELECT count FROM post_counter");
    if (query.exec()) {
        if (query.next()) {
            b = query.value(0).toInt() + 1;
        } else {
            b = 1; // If the table is empty, start from post id=1
        }
    } else {
        qDebug() << "Failed to execute SELECT query:" << query.lastError().text();
    }


    query.prepare("UPDATE post_counter SET count = :count");
    query.bindValue(":count", b);
    if (!query.exec()) {
        qDebug() << "Error updating post_counter: " << query.lastError().text();
    }

    if (!query.exec()) {
        qDebug() << "Failed to execute UPDATE query:" << query.lastError().text();
    }

    post1.Post_ID=query.exec("SELECT count FROM post_counter ");
    post1.Reposet_counter=0;

    post1.Time_sent= QDateTime::currentDateTime();
    if(PostDAO::savePost( post1)) {
        home *metr =new home;
        metr-> setWindowTitle("home");
        metr-> show();
    }


}


void start_post::on_pushButton_2_clicked()//select photo (ignored)
{

}


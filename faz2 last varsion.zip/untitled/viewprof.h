#ifndef VIEWPROF_H
#define VIEWPROF_H

#include <QMainWindow>

namespace Ui {
class viewprof;
}

class viewprof : public QMainWindow
{
    Q_OBJECT

public:
    explicit viewprof(QWidget *parent = nullptr);
    ~viewprof();

private slots:
    void on_pushButton_20_clicked();

    void on_pushButton_clicked();

private:
    Ui::viewprof *ui;
};

#endif // VIEWPROF_H

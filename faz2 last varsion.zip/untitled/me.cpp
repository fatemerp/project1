
#include "me.h"
#include "ui_me.h"
#include "home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "massaging.h"
#include <ctime>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "companydao.h"
#include "company.h"
#include "person.h"
#include "persondao.h"
#include "jobsc.h"
#include "mynetworkc.h"
#include "account.h"
#include "accountdao.h"
#include "make_company.h"
#include "notification.h"
int t2;

me::me(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::me)
{
    ui->setupUi(this);
    /////
    ui->comboBox->addItem("off");
    ui->comboBox->addItem("on");
    ///
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    //dark mood:
    QSqlQuery query;
    int color;
     query.exec("SELECT dm FROM darkmood ")   ;
     color=query.value(0).toInt();
     // white back ground
        if (color==0) me::setStyleSheet("background-color: rgb(234, 234, 234)");
     //gray back ground
       else if (color==1)  me::setStyleSheet("background-color: rgb(79, 79, 79)");

    ///

    QString id;
    id= query.exec("SELECT name FROM user ")   ;

     if (query.exec("SELECT type FROM user")) {
         while (query.next()) {
             t2 = query.value(0).toInt();
             break; // just first one
         }//showw account info:
         if(t2==0){
              company me=CompanyDAO::getCompanyByAccountID(id);
                      QString a1=me.Account_ID;
                      QString a2=me.Company_name;
                      QString a3=me.Email;
                      QString a4=me.Phone_number;
                      ui->label_3->setText(a1);
                      ui->label_4->setText(a2);
                      ui->label_6->setText(a3);
                      ui->label_8->setText(a4);

         }
         if(t2==1){
              person me =PersonDAO::getPersonByAccountId(id);
                    QString a1=me.Account_ID;
                    QString a2=me.First_Name+" "+me.Last_Name;
                    QString a3=me.Email;
                    QString a4=me.Phone_number;
                    ui->label_3->setText(a1);
                    ui->label_4->setText(a2);
                    ui->label_6->setText(a3);
                    ui->label_8->setText(a4);
         }
     }
}

me::~me()
{
    delete ui;
}


void me::on_pushButton_clicked()
{
    if(t2==1){
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();}
    else if (t2==0){
        mynetworkC *mtr1 =new mynetworkC;
         mtr1-> setWindowTitle("myNetworkc");
         mtr1-> show();
    }
}


void me::on_pushButton_2_clicked()
{
    if(t2==1){
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
    }
    else if (t2==0){
        jobsC *mtr1 =new jobsC;
         mtr1-> setWindowTitle("myNetworkc");
         mtr1-> show();}
}


void me::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void me::on_pushButton_4_clicked()
{
    home *metr =new home;
    metr-> setWindowTitle("home");
    metr-> show();
}


void me::on_pushButton_5_clicked()//serch box (in home page)
{


}


void me::on_pushButton_6_clicked()//make account company
{
    if (t2==0){}//its alredy an company accuont
    else{

        make_company *metr =new make_company;
        metr-> setWindowTitle("make_company");
        metr-> show();

    }
}


void me::on_pushButton_7_clicked()
{
    notification *metr =new notification;
    metr-> setWindowTitle("notification");
    metr-> show();
}


void me::on_comboBox_activated(int index)//dark mood:
{
    QSqlQuery q;
    switch (index) {
    case 0 ://means off -> white back ground
        me::setStyleSheet("background-color: rgb(255, 255, 255)");
        q.prepare("UPDATE darkmood SET dm = :type");
        q.bindValue(":type", 0);
        break;
    case 1 ://mean on ->gray back ground
        me::setStyleSheet("background-color: rgb(98, 107, 127)");
        q.prepare("UPDATE darkmood SET dm = :type");
        q.bindValue(":type", 1);
        break;
    }
}


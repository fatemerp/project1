#ifndef COMPANY_H
#define COMPANY_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include "content.h"
#include <ctime>
#include"account.h"


class company: public account
{
public:
    company();
   QVector<QString> Company_Jobs;
    QString Company_name;
    QVector<QString> Employee;
      QVector<QString> followers;
    void Creat_Job(QString job) {}
};

#endif // COMPANY_H

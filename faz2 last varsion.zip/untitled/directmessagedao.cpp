#include "directmessagedao.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "like.h"
#include "time.h"
#include "comment.h"
#include "post.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include "directmassage.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <ctime>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QDebug>
#include <QDateTime>
#include "person.h"

bool DirectMessageDAO::saveDirectMessage(const directmassage& directMessage) {
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return false;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO directmassage (sender_ID, Time_sent, Content_Text, Message_ID, To_who) VALUES (?, ?, ?, ?, ?)");
    query.addBindValue(directMessage.sender_ID);
    query.addBindValue(directMessage.Time_sent.toString(Qt::ISODate));
    query.addBindValue(directMessage.Content_Text);
    query.addBindValue(directMessage.Message_ID);
    query.addBindValue(directMessage.To_who);

    if (!query.exec()) {
        qDebug() << "Error executing SQL query:" << query.lastError().text();
        return false;
    }

    return true;
}

std::vector<directmassage> DirectMessageDAO::getAllDirectMessages() {
    std::vector<directmassage> directMessages;
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return directMessages;
    }

    QSqlQuery query("SELECT * FROM directmassage");
    while (query.next()) {
        directmassage directMessage;
        directMessage.sender_ID = query.value(0).toString();
        directMessage.Time_sent = QDateTime::fromString(query.value(1).toString(), Qt::ISODate);
        directMessage.Content_Text = query.value(2).toString();
        directMessage.Message_ID = query.value(3).toString();
        directMessage.To_who = query.value(4).toString();
        directMessages.push_back(directMessage);
    }

    return directMessages;
}

directmassage DirectMessageDAO::getDirectMessageByID(const QString& massageID) {
    directmassage directMessage;
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return directMessage;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM directmassage WHERE Message_ID = ?");
    query.addBindValue(massageID);
    directMessage.sender_ID = query.value(0).toString();
    directMessage.Time_sent = QDateTime::fromString(query.value(1).toString(), Qt::ISODate);
    directMessage.Content_Text = query.value(2).toString();
    directMessage.Message_ID = query.value(3).toString();
    directMessage.To_who = query.value(4).toString();
    if (!query.exec()) {
        qDebug() << "Error executing SQL query:" << query.lastError().text();
        return directMessage;
    }

    if (query.next()) {
        directMessage.sender_ID = query.value(0).toString();
        directMessage.Time_sent = QDateTime::fromString(query.value(1).toString(), Qt::ISODate);
        directMessage.Content_Text = query.value(2).toString();
        directMessage.Message_ID = query.value(3).toString();
        directMessage.To_who = query.value(4).toString();
    }

    return directMessage;
}

std::vector<directmassage> DirectMessageDAO::getDirectMessagesBetween(const QString& sender_id, const QString& receiver_id) {
    std::vector<directmassage> directMessages;
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\posts.db");

    if (!db.open()) {
        qDebug() << "Error opening database connection:" << db.lastError().text();
        return directMessages;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM directmassage WHERE (sender_ID = :sender_id AND To_who = :receiver_id) OR (sender_ID = :receiver_id AND To_who = :sender_id) ORDER BY Time_sent ASC");
    query.bindValue(":sender_id", sender_id);
    query.bindValue(":receiver_id", receiver_id);
    if (!query.exec()) {
        qDebug() << "Error executing SQL query:" << query.lastError().text();
        db.close();
        return directMessages;
    }

    while (query.next()) {
        directmassage directMessage;
        directMessage.Message_ID = query.value(0).toString();
        directMessage.To_who = query.value(1).toString();
        directMessage.sender_ID = query.value(2).toString();
        directMessage.Time_sent = QDateTime::fromString(query.value(3).toString(), Qt::ISODate);
        directMessage.Content_Text = query.value(4).toString();
        directMessages.push_back(directMessage);
    }

    db.close();

    std::sort(directMessages.begin(), directMessages.end(), [](const directmassage& a, const directmassage& b) {
        return a.Time_sent < b.Time_sent;
    });

    return directMessages;
}




QIODevice* DirectMessageDAO::getConnection() {
    static QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\posts.db");

    if (!db.isOpen()) {
        if (!db.open()) {
            qDebug() << "Error opening database connection:" << db.lastError().text();
            return nullptr;
        }
    }


}

std::vector<directmassage> DirectMessageDAO::getDirectMessagesByAccountID(const QString& account_id) {
    std::vector<directmassage> directMessages;
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return directMessages;
    }

    QSqlQuery query;
    query.prepare("SELECT * FROM directmassage WHERE sender_ID = :account_id OR To_who = :account_id");
    query.bindValue(":account_id", account_id);
    if (!query.exec()) {
        qDebug() << "Error executing query:" << query.lastError().text();
        return directMessages;
    }

    while (query.next()) {
        directmassage directMessage;
        directMessage.sender_ID = query.value(0).toString();
        directMessage.Time_sent = QDateTime::fromString(query.value(1).toString(), Qt::ISODate);
        directMessage.Content_Text = query.value(2).toString();
        directMessage.Message_ID = query.value(3).toString();
        directMessage.To_who = query.value(4).toString();
        directMessages.push_back(directMessage);
    }

    return directMessages;
}

std::vector<QString> DirectMessageDAO::getAccountIDsWithDirectMessages(const QString& account_id) {
    std::vector<QString> accountIDs;
    QIODevice* db = getConnection();
    if (!db->isOpen()) {
        qDebug() << "Error opening database connection";
        return accountIDs;
    }

    QSqlQuery query;
    query.prepare("SELECT DISTINCT sender_ID, To_who FROM directmassage WHERE sender_ID = :account_id OR To_who = :account_id");
    query.bindValue(":account_id", account_id);
    if (!query.exec()) {
        qDebug() << "Error executing query:" << query.lastError().text();
        return accountIDs;
    }

    while (query.next()) {
        QString senderID = query.value(0).toString();
        QString toWho = query.value(1).toString();
        if (senderID != account_id) {
            accountIDs.push_back(senderID);
        }
        if (toWho != account_id) {
            accountIDs.push_back(toWho);
        }
    }


    std::sort(accountIDs.begin(), accountIDs.end());
    accountIDs.erase(std::unique(accountIDs.begin(), accountIDs.end()), accountIDs.end());

    return accountIDs;
}



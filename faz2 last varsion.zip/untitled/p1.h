#ifndef P1_H
#define P1_H

#include <QMainWindow>

namespace Ui {
class p1;
}

class p1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit p1(QWidget *parent = nullptr);
    ~p1();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::p1 *ui;
};

#endif // P1_H

#ifndef LIKE_H
#define LIKE_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include <ctime>
#include <ctime>

class like
{
public:
like();
QString Who_liked_ID;
QString Like_ID;
QDateTime Time;
int post_id;
};

#endif // LIKE_H

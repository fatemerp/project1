#include "mynetworkc.h"
#include "ui_mynetworkc.h"
#include "jobsc.h"
#include "mynetworkc.h"
#include "home.h"
#include "massaging.h"
#include "me.h"
#include "jobsc.h"
#include "mynetworkc.h"
#include "home.h"
#include "mynetworkc.h"
#include "massaging.h"
#include "me.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"

#include "companydao.h"
#include "person.h"
#include "persondao.h"

QVector<QString>followers;

mynetworkC::mynetworkC(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::mynetworkC)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    //dark mood:
    QSqlQuery query;
    int color;
     query.exec("SELECT dm FROM darkmood ")   ;
     color=query.value(0).toInt();
     // white back ground
        if (color==0) mynetworkC::setStyleSheet("background-color: rgb(234, 234, 234)");
     //gray back ground
       else if (color==1)  mynetworkC::setStyleSheet("background-color: rgb(79, 79, 79)");


}

mynetworkC::~mynetworkC()
{
    delete ui;
}

void mynetworkC::on_pushButton_clicked()
{
    home *mtr =new home;
     mtr-> setWindowTitle("home");
     mtr-> show();
}


void mynetworkC::on_pushButton_2_clicked()
{
    jobsC *mtr1 =new jobsC;
     mtr1-> setWindowTitle("myNetworkc");
     mtr1-> show();
}


void mynetworkC::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void mynetworkC::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


void mynetworkC::on_pushButton_5_clicked()//show followers
{
    QSqlQuery query;
    QString id;
    id= query.exec("SELECT name FROM user ")   ;
    followers= CompanyDAO::getCompanyFollowersByAccountID(id);

    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_2->setText(a1);
        ui->label_3->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_2->setText(a1);
            ui->label_3->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_4->setText(a1);
        ui->label_5->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_4->setText(a1);
            ui->label_5->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_6->setText(a1);
        ui->label_5->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_6->setText(a1);
            ui->label_7->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_8->setText(a1);
        ui->label_9->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_8->setText(a1);
            ui->label_9->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_10->setText(a1);
        ui->label_11->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_10->setText(a1);
            ui->label_11->setText(a2);
        }
    }
}


void mynetworkC::on_pushButton_6_clicked()//show more followers:
{
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_2->setText(a1);
        ui->label_3->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_2->setText(a1);
            ui->label_3->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_4->setText(a1);
        ui->label_5->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_4->setText(a1);
            ui->label_5->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_6->setText(a1);
        ui->label_5->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_6->setText(a1);
            ui->label_7->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_8->setText(a1);
        ui->label_9->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_8->setText(a1);
            ui->label_9->setText(a2);
        }
    }
    if (!followers.empty()) {
        QString s1 = followers.back();
        followers.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString a1=co1.Account_ID;
        QString a2=co1.Company_name;
        ui->label_10->setText(a1);
        ui->label_11->setText(a2);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString a1=pe1.Account_ID;
            QString a2=pe1.First_Name+" "+pe1.Last_Name;
            ui->label_10->setText(a1);
            ui->label_11->setText(a2);
        }
    }
}


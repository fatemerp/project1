#include "p1.h"
#include "ui_p1.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include"directmassage.h"
#include "directmessagedao.h"
#include "massaging.h"
#include "person.h"
#include "persondao.h"

QString id1;
QString id2;
p1::p1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::p1)
{
    ui->setupUi(this);
    ////
    QSqlQuery query;

    if (query.exec("SELECT name FROM user")) {
        while (query.next()) {
            id1 = query.value(0).toString();
            break; // just first one
        }
    }
    if (query.exec("SELECT id FROM lastdm")) {
        while (query.next()) {
            id2 = query.value(0).toString();
            break; // just first one
        }
        person pe1=PersonDAO::getPersonByAccountId(id2);
        QString a1=pe1.Account_ID;
        QString a2=pe1.First_Name+" "+pe1.Last_Name;
        ui->label->setText(a1);
        ui->label_2->setText(a2);
    }

 std::vector<directmassage>dm= DirectMessageDAO::getDirectMessagesBetween(id1,id2);
 //show massages:
 if (!dm.empty()) {
     directmassage dm1 = dm.back();
     dm.pop_back();
     QString a1 =dm1.sender_ID;
     QString a2 = dm1.Content_Text;
     ui->label_5->setText(a1);
     ui->label_6->setText(a2);

 }
 if (!dm.empty()) {
     directmassage dm1 = dm.back();
     dm.pop_back();
     QString a1 =dm1.sender_ID;
     QString a2 = dm1.Content_Text;
     ui->label_9->setText(a1);
     ui->label_10->setText(a2);

 }
 if (!dm.empty()) {
     directmassage dm1 = dm.back();
     dm.pop_back();
     QString a1 =dm1.sender_ID;
     QString a2 = dm1.Content_Text;
     ui->label_11->setText(a1);
     ui->label_12->setText(a2);

 }
 if (!dm.empty()) {
     directmassage dm1 = dm.back();
     dm.pop_back();
     QString a1 =dm1.sender_ID;
     QString a2 = dm1.Content_Text;
     ui->label_13->setText(a1);
     ui->label_14->setText(a2);

 }

}

p1::~p1()
{
    delete ui;
}

void p1::on_pushButton_clicked()//back to massaging page
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void p1::on_pushButton_2_clicked()//send dm
{
    directmassage newdm;
    newdm.Content_Text=ui-> lineEdit ->text();
    newdm.To_who=id2;
    newdm.sender_ID=id1;
    newdm.Time_sent =QDateTime::currentDateTime();
    //set massage id:
    QSqlQuery query;
    int b;
    query.exec("SELECT count1 FROM post_counter");
    if (query.exec()) {
        if (query.next()) {
            b = query.value(0).toInt() + 1;
        } else {
            b = 1; // If the table is empty, start from 1
        }
    } else {
        qDebug() << "Failed to execute SELECT query:" << query.lastError().text();
    }


    query.prepare("UPDATE post_counter SET count1 = :count");
    query.bindValue(":count", b);
    if (!query.exec()) {
        qDebug() << "Error updating post_counter: " << query.lastError().text();
    }

    if (!query.exec()) {
        qDebug() << "Failed to execute UPDATE query:" << query.lastError().text();
    }

    newdm.Message_ID=query.exec("SELECT count1 FROM post_counter ");
    DirectMessageDAO::saveDirectMessage(newdm);
}


#ifndef PERSONDAO_H
#define PERSONDAO_H


#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>
#include "person.h"
#include <ctime>
#include <ctime>

class PersonDAO {
public:
static bool createPerson(person&  ) ;
static QVector<person> getPersonsByJob(const QString& );
static QVector<person> getAllPersons() ;
 static person getPersonByAccountId(const QString& );
private:
static QString serializeVector(const QVector<QString>& ) ;
static QVector<QString> deserializeVector(const QString&  ) ;
};


#endif // PERSONDAO_H

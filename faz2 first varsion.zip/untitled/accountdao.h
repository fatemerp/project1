#ifndef ACCOUNTDAO_H
#define ACCOUNTDAO_H


//class accountDAO
//{
//public:
//   accountDAO();
//};

//#endif // ACCOUNTDAO_H


#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include "account.h"
#include "comment.h"
#include "post.h"
#include "directmassage.h"
#include "postdao.h"
#include "directmassage.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <ctime>


class accountDAO {
public:

 static void saveAccount(const account& ) ;
static QString* getAccountFollowing(const QString& );
static std::vector<QString> getAccountIDsByPartialID(const QString& );
static void addConnection(const QString& id1, const QString& id2);
private:
 static void saveAccountPosts(const QString& , const QVector<post*>& ) ;

 static void saveAccountDirectMessages(const QString& , const QVector<directmassage*>& ) ;

  static void saveAccountFollowing(const QString&  , const QVector<QString>&  ) ;
};
#endif

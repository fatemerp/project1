#ifndef COMMENT_H
#define COMMENT_H
#include "QDateTime"
#include"QVector"
#include "QImage"
#include "content.h"
#include <ctime>

class comment : public content
{
public:
comment();
QString Post_ID;
QString comment_ID;
};

#endif // COMMENT_H

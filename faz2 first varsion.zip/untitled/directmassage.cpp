#include "directmassage.h"

directmassage::directmassage()
{

}

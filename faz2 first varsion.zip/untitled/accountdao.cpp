
#include "accountdao.h"
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QImageReader>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSqlDatabase>

#include <QSqlQuery>
#include <QDebug>
#include "account.h"
#include "comment.h"
#include "post.h"
#include "directmassage.h"
#include "postdao.h"
#include "directmassage.h"
#include <QImage>
#include <QSqlError>
#include <QIODevice>
#include <QBuffer>
#include <ctime>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QIODevice>

    void accountDAO:: saveAccount(const account& account) {
        QSqlDatabase db = QSqlDatabase::database();
        QSqlQuery query(db);

        query.prepare("INSERT INTO accounts (account_id, phone_number, email, connection) "
                     "VALUES (?, ?, ?, ?, ?)");

        query.bindValue(0, account.Account_ID);
        query.bindValue(1, account.Phone_number);
        query.bindValue(2, account.Email);
        query.bindValue(3, account.Connection);

        if (!query.exec()) {
            qDebug() << "Failed to save account:" << query.lastError().text();
        }
        saveAccountPosts(account.Account_ID, account.Posts);
        saveAccountDirectMessages(account.Account_ID, account.DM);
        saveAccountFollowing(account.Account_ID, account.following);
    }


   void accountDAO::  saveAccountPosts(const QString& accountId, const QVector<post*>& posts) {
        QSqlDatabase db = QSqlDatabase::database();
            QSqlQuery query(db);

            query.prepare("INSERT INTO posts (account_id, post_id, content_text, time_sent) "
                         "VALUES (?, ?, ?, ?)");


            for (const auto& post : posts) {
                query.bindValue(0, accountId);
                query.bindValue(1, post->Post_ID);
                query.bindValue(2, post->Content_Text);


                //QByteArray imageData;
                //QBuffer buffer(&imageData);
               // buffer.open(QIODevice::WriteOnly);
                //post->Content_Picture.save(&buffer, "PNG");
                //query.bindValue(3, imageData);

                //query.bindValue(4, post->Time_Sent.toString(Qt::ISODate));

                if (!query.exec()) {
                    qDebug() << "Failed to save post:" << query.lastError().text();
                }
            }

    }

     void accountDAO:: saveAccountDirectMessages(const QString& accountId, const QVector<directmassage*>& messages) {
        QSqlDatabase db = QSqlDatabase::database();
            QSqlQuery query(db);

            query.prepare("INSERT INTO direct_messages (account_id, message_id, sender_id, receiver_id, time_sent, content_text) "
                         "VALUES (?, ?, ?, ?, ?, ?)");

            for (const auto& message : messages) {
                query.bindValue(0, accountId);
                query.bindValue(1, message->Message_ID);
                query.bindValue(2, message->sender_ID);
                query.bindValue(3, message->To_who );
                query.bindValue(4, message->Time_sent.toString(Qt::ISODate));
                query.bindValue(5, message->Content_Text);


                //QByteArray imageData;
                //QBuffer buffer(&imageData);
                //buffer.open(QIODevice::WriteOnly);
                //message->Content_Picture.save(&buffer, "PNG");
                //query.bindValue(6, imageData);

                if (!query.exec()) {
                    qDebug() << "Failed to save direct message:" << query.lastError().text();
                }
            }

    }

      void accountDAO::  saveAccountFollowing(const QString& accountId, const QVector<QString>& following) {
        QSqlDatabase db = QSqlDatabase::database();
            QSqlQuery query(db);


            query.prepare("INSERT INTO following (account_id, followed_account_id) "
                         "VALUES (?, ?)");


            for (const auto& followedId : following) {
                query.bindValue(0, accountId);
                query.bindValue(1, followedId);

                if (!query.exec()) {
                    qDebug() << "Failed to save followed account:" << query.lastError().text();
                }
            }

    }

      QString* accountDAO::getAccountFollowing(const QString& accountId) {
          QSqlDatabase db = QSqlDatabase::database();
          QSqlQuery query(db);


          query.prepare("SELECT followed_account_id FROM following WHERE account_id = ?");
          query.bindValue(0, accountId);

          QStringList followingList;
          if (query.exec()) {
              while (query.next()) {
                  followingList.append(query.value(0).toString());
              }
          } else {
              qDebug() << "Failed to retrieve followed accounts:" << query.lastError().text();
          }


          QString* following = new QString[followingList.size()];
          for (int i = 0; i < followingList.size(); i++) {
              following[i] = followingList[i];
          }

          return following;
      }

      std::vector<QString> accountDAO::getAccountIDsByPartialID(const QString& partialID) {
          std::vector<QString> matchingAccountIDs;
          QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
          db.setDatabaseName("d:\\posts.db");

          if (!db.open()) {
              qDebug() << "Error opening database connection:" << db.lastError().text();
              return matchingAccountIDs;
          }

          QSqlQuery query;
          query.prepare("SELECT account_id FROM accounts WHERE account_id LIKE :partialID");
          query.bindValue(":partialID", "%" + partialID + "%");

          if (!query.exec()) {
              qDebug() << "Error executing SQL query:" << query.lastError().text();
              db.close();
              return matchingAccountIDs;
          }

          while (query.next()) {
              matchingAccountIDs.push_back(query.value(0).toString());
          }

          db.close();
          return matchingAccountIDs;
      }

      void accountDAO::addConnection(const QString& id1, const QString& id2) {
          QSqlDatabase db = QSqlDatabase::database();
          QSqlQuery query(db);

          // Add id2 to the connection of id1
          query.prepare("UPDATE accounts SET connection = CONCAT(connection, ?, ',') WHERE account_id = ?");
          query.bindValue(0, id2);
          query.bindValue(1, id1);
          if (!query.exec()) {
              qDebug() << "Failed to add connection for account" << id1 << ":" << query.lastError().text();
              return;
          }

          // Add id1 to the connection of id2
          query.prepare("UPDATE accounts SET connection = CONCAT(connection, ?, ',') WHERE account_id = ?");
          query.bindValue(0, id1);
          query.bindValue(1, id2);
          if (!query.exec()) {
              qDebug() << "Failed to add connection for account" << id2 << ":" << query.lastError().text();
              return;
          }
      }

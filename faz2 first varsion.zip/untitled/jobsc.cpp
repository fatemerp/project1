#include "jobsc.h"
#include "ui_jobsc.h"
//#include "jobsc.h"
#include "mynetworkc.h"
#include "home.h"
#include "mynetworkc.h"
#include "massaging.h"
#include "me.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "start_job.h"
#include "companydao.h"
#include "person.h"
#include "persondao.h"
#include "apply_job.h"
QString idc;
company mec;
apply_job* j1;
apply_job* j2;
apply_job* j3;
QVector<apply_job*> requests;

jobsC::jobsC(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::jobsC)
{
    ui->setupUi(this);
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    ui->setupUi(this);
    QSqlQuery query;
    idc = query.exec("SELECT name FROM user ");
    mec = CompanyDAO::getCompanyByAccountID(idc);
    requests = apply_job::getJobApplicationsByCompanyName(mec.Company_name);
    if (!requests.isEmpty()) {
        apply_job* job1 = requests.back();
        requests.pop_back();
        j1=job1;
        QString a1=j1->job_name;
        QString i=j1->sender_id;
        person p1= PersonDAO::getPersonByAccountId(i);
        QString a2=p1.First_Name+" "+p1.Last_Name;
        ui->label_2->setText(a1);
        ui->label_3->setText(a2);
    }
    if (!requests.isEmpty()) {
        apply_job* job2 = requests.back();
        requests.pop_back();
        j2=job2;
        QString a1=j2->job_name;
        QString i=j2->sender_id;
        person p1= PersonDAO::getPersonByAccountId(i);
        QString a2=p1.First_Name+" "+p1.Last_Name;
        ui->label_2->setText(a1);
        ui->label_3->setText(a2);
    }
    if (!requests.isEmpty()) {
        apply_job* job3 = requests.back();
        requests.pop_back();
        j3=job3;
        QString a1=j3->job_name;
        QString i=j3->sender_id;
        person p1= PersonDAO::getPersonByAccountId(i);
        QString a2=p1.First_Name+" "+p1.Last_Name;
        ui->label_2->setText(a1);
        ui->label_3->setText(a2);
    }
}


jobsC::~jobsC()
{
    delete ui;
}

void jobsC::on_pushButton_2_clicked()
{
    home *jtr =new home;
    jtr-> setWindowTitle("home");
    jtr-> show();
}


void jobsC::on_pushButton_clicked()
{
    mynetworkC *mtr1 =new mynetworkC;
     mtr1-> setWindowTitle("myNetworkc");
     mtr1-> show();
}


void jobsC::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void jobsC::on_pushButton_4_clicked()
{
    me *jtr =new me;
    jtr-> setWindowTitle("me");
    jtr-> show();
}





void jobsC::on_pushButton_6_clicked()
{
  QString jn1=j1->job_name;
  QString cn1=j1->company_name;
  QString e1=j1->sender_id;
  int v1=1;//1 mean accept
  jobsC::setV(cn1,jn1,idc,v1);
  CompanyDAO::AddEmployee(e1,cn1);
}


void jobsC::on_pushButton_5_clicked()
{
    QString jn1=j1->job_name;
    QString cn1=j1->company_name;
    QString e1=j1->sender_id;
    int v1=2;//2 maen ignore
    jobsC::setV(cn1,jn1,idc,v1);
}


void jobsC::on_pushButton_7_clicked()
{
    QString jn1=j2->job_name;
    QString cn1=j2->company_name;
    QString e1=j2->sender_id;
    int v1=1;//1 mean accept
    jobsC::setV(cn1,jn1,idc,v1);
    CompanyDAO::AddEmployee(e1,cn1);
}


void jobsC::on_pushButton_9_clicked()
{
    QString jn1=j2->job_name;
    QString cn1=j2->company_name;
    QString e1=j2->sender_id;
    int v1=2;//2 maen ignore
    jobsC::setV(cn1,jn1,idc,v1);
}


void jobsC::on_pushButton_8_clicked()
{
    QString jn1=j3->job_name;
    QString cn1=j3->company_name;
    QString e1=j3->sender_id;
    int v1=1;//1 mean accept
    jobsC::setV(cn1,jn1,idc,v1);
    CompanyDAO::AddEmployee(e1,cn1);
}


void jobsC::on_pushButton_10_clicked()
{
    QString jn1=j3->job_name;
    QString cn1=j3->company_name;
    QString e1=j3->sender_id;
    int v1=2;//2 maen ignore
    jobsC::setV(cn1,jn1,idc,v1);
}

bool jobsC::setV(const QString& companyName, const QString& jobName, const QString& senderID, int v){


    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("your_database.db");

    QSqlQuery query;
    query.prepare("UPDATE apply_job SET v = :v WHERE Company_Name = :companyName AND Job_Name = :jobName AND Sender_ID = :senderID");
    query.bindValue(":v", v);
    query.bindValue(":companyName", companyName);
    query.bindValue(":jobName", jobName);
    query.bindValue(":senderID", senderID);

    if (!query.exec()) {
        db.close();
        return false;
    }


    return true;
}

void jobsC::on_pushButton_11_clicked()//craet job
{
    start_job *mstr =new start_job;
    mstr-> setWindowTitle("start a new job");
    mstr-> show();
}


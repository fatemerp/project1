#include "make_company.h"
#include "ui_make_company.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "companydao.h"
#include "company.h"
#include "person.h"
#include "persondao.h"
#include "jobsc.h"
#include "me.h"

make_company::make_company(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::make_company)
{
    ui->setupUi(this);
}

make_company::~make_company()
{
    delete ui;
}

void make_company::on_pushButton_clicked()//save as company:
{
    QSqlQuery query;
    QString id;
    id= query.exec("SELECT name FROM user ")   ;
    person p1= PersonDAO::getPersonByAccountId(id);
    company c1;
    c1.Account_ID=p1.Account_ID;
    c1.Company_name= ui->lineEdit->text();
    c1.Email=p1.Email;
    c1.Phone_number=p1.Phone_number;
    c1.DM=p1.DM;
    CompanyDAO::saveCompany(c1);
    query.prepare("DELETE FROM persons WHERE Account_ID = ?");
        query.addBindValue(p1.Account_ID);
        me *metr =new me;
        metr-> setWindowTitle("me");
        metr-> show();
}


void make_company::on_pushButton_2_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


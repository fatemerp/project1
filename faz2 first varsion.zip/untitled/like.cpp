#include "like.h"

like::like()
{

}

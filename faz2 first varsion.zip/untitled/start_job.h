#ifndef START_JOB_H
#define START_JOB_H

#include <QMainWindow>

namespace Ui {
class start_job;
}

class start_job : public QMainWindow
{
    Q_OBJECT

public:
    explicit start_job(QWidget *parent = nullptr);
    ~start_job();

private slots:
    void on_pushButton_clicked();

private:
    Ui::start_job *ui;
};

#endif // START_JOB_H

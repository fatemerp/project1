
#include "home.h"
#include "ui_home.h"
#include "mynetwork.h"
#include "jobs.h"
#include "massaging.h"
#include "me.h"
#include "content.h"
#include "post.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "postdao.h"
#include "start_post.h"
#include <ctime>
#include "postdao.h"
#include <QApplication>
#include <QLabel>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVBoxLayout>
#include <QWidget>
#include <accountdao.h>
#include "jobsc.h"
#include "mynetworkc.h"
#include "companydao.h"
#include "company.h"
#include "person.h"
#include "persondao.h"
#include "jobsc.h"
#include "mynetworkc.h"
#include "account.h"
#include "accountdao.h"
int t1;
int a=-9;
QVector<post*> posts;
home::home(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::home)
{
    ui->setupUi(this);
    ///
    QSqlQuery query;
    QString id;
    id= query.exec("SELECT name FROM user ")   ;
    //get posts of followings:
    QString* following = new QString[20];
    following= accountDAO::getAccountFollowing(id);

    for (int i = 0; following[i] != nullptr; i++) {
        QString followedId = following[i];
        posts.append(PostDAO::getPostBySenderId(followedId));//like push_back but for string and zanciri
        delete[] following;
    }

    if (query.exec("SELECT type FROM user")) {//to feager it account company
        while (query.next()) {
            t1 = query.value(0).toInt();
            break; // just first one
        }
    }
    on_pushButton_6_clicked();//first time show posts
}

home::~home()
{
    delete ui;

}




void home::on_pushButton_clicked()
{
    if(t1==1){
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();}
    else if (t1==0){
        mynetworkC *mtr1 =new mynetworkC;
         mtr1-> setWindowTitle("myNetworkc");
         mtr1-> show();
    }
}


void home::on_pushButton_2_clicked()
{
    if(t1==1){
    jobs *jtr =new jobs;
    jtr-> setWindowTitle("jobs");
    jtr-> show();
    }
    else if (t1==0){
        jobsC *mtr1 =new jobsC;
         mtr1-> setWindowTitle("myNetworkc");
         mtr1-> show();}
}


void home::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void home::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}


void home::on_pushButton_5_clicked()//search box:
{

    QString a=ui-> lineEdit ->text();
    std::vector< QString >search = accountDAO::getAccountIDsByPartialID(a);
    if (!search.empty()) {
        QString s1 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_4->setText(coid);
        ui->label_5->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_4->setText(coid);
            ui->label_5->setText(name);
        }
    }

    if (!search.empty()) {
        QString s1 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_6->setText(coid);
        ui->label_7->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_6->setText(coid);
            ui->label_7->setText(name);
        }
    }

    if (!search.empty()) {
        QString s1 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_8->setText(coid);
        ui->label_9->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_8->setText(coid);
            ui->label_9->setText(name);
        }
    }

    if (!search.empty()) {
        QString s1 = search.back();
        search.pop_back();
        if(CompanyDAO::isAccountInCompanyTable(s1)){
        company co1=CompanyDAO::getCompanyByAccountID(s1);
        QString name = co1.Company_name;
        QString coid=co1.Account_ID;
        ui->label_10->setText(coid);
        ui->label_11->setText(name);
        }
        else{
            person pe1=PersonDAO::getPersonByAccountId(s1);
            QString name = pe1.First_Name+ " " + pe1.Last_Name;
            QString coid=pe1.Account_ID;
            ui->label_10->setText(coid);
            ui->label_11->setText(name);
        }
    }

}


void home::on_pushButton_6_clicked()
{
    start_post *str =new start_post;
     str-> setWindowTitle("start_post");
     str-> show();
}


void home::on_pushButton_7_clicked()//show more posts:
{

    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_12->setText(i);
        ui->label_13->setText(t);

         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_14->setText(i);
        ui->label_15->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_16->setText(i);
        ui->label_17->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_18->setText(i);
        ui->label_19->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_20->setText(i);
        ui->label_21->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_22->setText(i);
        ui->label_23->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_24->setText(i);
        ui->label_25->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_26->setText(i);
        ui->label_27->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_28->setText(i);
        ui->label_29->setText(t);
         }
    if (!posts.isEmpty()) {
        post* post1 = posts.back();
        posts.pop_back();
        QString a=post1->Content_Text;
        QString i=post1->sender_ID;
        QString t=post1->Content_Text;
        ui->label_30->setText(i);
        ui->label_31->setText(t);
         }




}



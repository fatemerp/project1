#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "home.h"
#include "cstring"
#include <ctime>

//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "companydao.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //data base
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QSqlQuery q;
    QString name1 = ui->lineEdit->text();
    int type1;

if(CompanyDAO::isAccountInCompanyTable(name1)){
   type1=0;
}
else{type1=1;}


    q.exec("UPDATE user SET name='"+name1+"' ");


    q.prepare("UPDATE user SET type = :type");
    q.bindValue(":type", QString::number(type1));


    ///
    home *jtr =new home;
    jtr-> setWindowTitle("home");
    jtr-> show();
}


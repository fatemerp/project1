#include "company.h"

company::company()
{

}

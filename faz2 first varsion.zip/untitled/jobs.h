#ifndef JOBS_H
#define JOBS_H

#include <QMainWindow>
#include <ctime>

namespace Ui {
class jobs;
}

class jobs : public QMainWindow
{
Q_OBJECT

public:
explicit jobs(QWidget *parent = nullptr);
~jobs();
bool isJobApplicationExists(const QString& , const QString& , const QString& );
private slots:
void on_pushButton_2_clicked();

void on_pushButton_clicked();

void on_pushButton_3_clicked();

void on_pushButton_4_clicked();

void on_pushButton_6_clicked();

void on_pushButton_7_clicked();

void on_pushButton_8_clicked();

void on_pushButton_9_clicked();

void on_pushButton_10_clicked();

void on_pushButton_11_clicked();

private:
Ui::jobs *ui;
};

#endif // JOBS_H

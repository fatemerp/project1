
#include "jobs.h"
#include "ui_jobs.h"
#include "home.h"
#include "mynetwork.h"
#include "massaging.h"
#include "me.h"
#include <ctime>
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
#include "jobdao.h"
#include "job.h"
#include "jobsc.h"
#include "mynetworkc.h"

job* job1;
job* job2;
job* job3;
job* job4;
job* job5;
 QString id;
QVector<job*> myjobs;
jobs::jobs(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::jobs)
{
    ui->setupUi(this);
    ///open database
    QSqlDatabase database;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\posts.db");
    database.open();
    ui->setupUi(this);
    /////
    QSqlQuery query;

    if (query.exec("SELECT name FROM user")) {
        while (query.next()) {
            id = query.value(0).toString();
            break; //just first one
        }
    } else {
        qDebug() << "Failed to retrieve sender_id:" << query.lastError().text();
    }

    QString my_job;
    query.prepare("SELECT job FROM persons WHERE Account_ID = :account_id");
    query.bindValue(":account_id", id);
    if (query.exec()) {
        if (query.next()) {
            my_job = query.value(0).toString();
            QVector<job> jobs = JobDAO::getJobByName(my_job);//for append shouldnt be *
            for (const auto& j : jobs) {
                myjobs.append(new job(j));
            }
            ////
            if (!myjobs.isEmpty()) {
                 job1 = myjobs.back();
                myjobs.pop_back();
                QString a1=job1->job_name+" "+job1->Company_name+" "+job1->location+" "+job1->type+" "+job1->salary+
                        " "+job1->workPlace_type;
                ui->label_3->setText(a1);
                 }
            if (!myjobs.isEmpty()) {
                 job2 = myjobs.back();
                myjobs.pop_back();
                QString a1=job2->job_name+" "+job2->Company_name+" "+job2->location+" "+job2->type+" "+job2->salary+
                        " "+job2->workPlace_type;
                ui->label_4->setText(a1);
                 }
            if (!myjobs.isEmpty()) {
                 job3 = myjobs.back();
                myjobs.pop_back();
                QString a1=job3->job_name+" "+job3->Company_name+" "+job3->location+" "+job3->type+" "+job3->salary+
                        " "+job3->workPlace_type;
                ui->label_5->setText(a1);
                 }
            if (!myjobs.isEmpty()) {
                 job4 = myjobs.back();
                myjobs.pop_back();
                QString a1=job4->job_name+" "+job4->Company_name+" "+job4->location+" "+job4->type+" "+job4->salary+
                        " "+job4->workPlace_type;
                ui->label_6->setText(a1);
                 }
            if (!myjobs.isEmpty()) {
                 job5 = myjobs.back();
                myjobs.pop_back();
                QString a1=job5->job_name+" "+job5->Company_name+" "+job5->location+" "+job5->type+" "+job5->salary+
                        " "+job5->workPlace_type;
                ui->label_7->setText(a1);
                 }

            ////
        }
    } else {
        qDebug() << "Failed to retrieve job:" << query.lastError().text();
    }

}

jobs::~jobs()
{
    delete ui;
}

void jobs::on_pushButton_clicked()
{
   myNetwork *mtr =new myNetwork;
    mtr-> setWindowTitle("myNetwork");
    mtr-> show();
}


void jobs::on_pushButton_2_clicked()
{
    home *jtr =new home;
    jtr-> setWindowTitle("home");
    jtr-> show();
}


void jobs::on_pushButton_3_clicked()
{
    massaging *mstr =new massaging;
    mstr-> setWindowTitle("massaging");
    mstr-> show();
}


void jobs::on_pushButton_4_clicked()
{
    me *metr =new me;
    metr-> setWindowTitle("me");
    metr-> show();
}

void jobs::on_pushButton_6_clicked()
{
    if (!myjobs.isEmpty()) {
         job1 = myjobs.back();
        myjobs.pop_back();
        QString a1=job1->job_name+" "+job1->Company_name+" "+job1->location+" "+job1->type+" "+job1->salary+
                " "+job1->workPlace_type;
        ui->label_3->setText(a1);
         }
    if (!myjobs.isEmpty()) {
         job2 = myjobs.back();
        myjobs.pop_back();
        QString a1=job2->job_name+" "+job2->Company_name+" "+job2->location+" "+job2->type+" "+job2->salary+
                " "+job2->workPlace_type;
        ui->label_4->setText(a1);
         }
    if (!myjobs.isEmpty()) {
         job3 = myjobs.back();
        myjobs.pop_back();
        QString a1=job3->job_name+" "+job3->Company_name+" "+job3->location+" "+job3->type+" "+job3->salary+
                " "+job3->workPlace_type;
        ui->label_5->setText(a1);
         }
    if (!myjobs.isEmpty()) {
         job4 = myjobs.back();
        myjobs.pop_back();
        QString a1=job4->job_name+" "+job4->Company_name+" "+job4->location+" "+job4->type+" "+job4->salary+
                " "+job4->workPlace_type;
        ui->label_6->setText(a1);
         }
    if (!myjobs.isEmpty()) {
         job5 = myjobs.back();
        myjobs.pop_back();
        QString a1=job5->job_name+" "+job5->Company_name+" "+job5->location+" "+job5->type+" "+job5->salary+
                " "+job5->workPlace_type;
        ui->label_7->setText(a1);
         }

}


void jobs::on_pushButton_7_clicked()
{
    QString cn=job1->Company_name;
    QString jn=job1->job_name;
    if(jobs::isJobApplicationExists(cn,jn,id)){

    }
    else{
    QSqlQuery query;
    query.prepare("INSERT INTO job_apply (company_name, job_name, sender_id,v) VALUES (?, ?, ?,?)");
    query.addBindValue(job1->Company_name);
    query.addBindValue(job1->job_name);
    query.addBindValue(id);
    query.addBindValue(0);
    if (!query.exec()) {
        qDebug() << "Error saving company:" << query.lastError().text();
        ;
    }
}//end of else

}

bool jobs::isJobApplicationExists(const QString& companyName, const QString& jobName, const QString& senderID) {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\posts.db"); // Replace with the actual name of your database file

    if (!db.open()) {
        qDebug() << "Error opening database connection:" << db.lastError().text();
        return false;
    }

    QSqlQuery query;
    query.prepare("SELECT COUNT(*) FROM apply_job WHERE company_name = :companyName AND job_name = :jobName AND sender_id = :senderID");
    query.bindValue(":companyName", companyName);
    query.bindValue(":jobName", jobName);
    query.bindValue(":senderID", senderID);

    if (!query.exec()) {

        db.close();
        return false;
    }

    if (query.next() && query.value(0).toInt() > 0) {
        db.close();
        return true;
    } else {
        db.close();
        return false;
    }
}

void jobs::on_pushButton_8_clicked()
{
    QString cn=job2->Company_name;
    QString jn=job2->job_name;
    if(jobs::isJobApplicationExists(cn,jn,id)){

    }
    else{
    QSqlQuery query;
    query.prepare("INSERT INTO job_apply (company_name, job_name, sender_id,v) VALUES (?, ?, ?,?)");
    query.addBindValue(job2->Company_name);
    query.addBindValue(job2->job_name);
    query.addBindValue(id);
    query.addBindValue(0);
    if (!query.exec()) {
        qDebug() << "Error saving company:" << query.lastError().text();
        ;
    }
}//end of else
}


void jobs::on_pushButton_9_clicked()
{
    QString cn=job3->Company_name;
    QString jn=job3->job_name;
    if(jobs::isJobApplicationExists(cn,jn,id)){

    }
    else{
    QSqlQuery query;
    query.prepare("INSERT INTO job_apply (company_name, job_name, sender_id,v) VALUES (?, ?, ?,?)");
    query.addBindValue(job3->Company_name);
    query.addBindValue(job3->job_name);
    query.addBindValue(id);
    query.addBindValue(0);
    if (!query.exec()) {
        qDebug() << "Error saving company:" << query.lastError().text();
        ;
    }
}//end of else
}


void jobs::on_pushButton_10_clicked()
{
    QString cn=job4->Company_name;
    QString jn=job4->job_name;
    if(jobs::isJobApplicationExists(cn,jn,id)){

    }
    else{
    QSqlQuery query;
    query.prepare("INSERT INTO job_apply (company_name, job_name, sender_id,v) VALUES (?, ?, ?,?)");
    query.addBindValue(job4->Company_name);
    query.addBindValue(job4->job_name);
    query.addBindValue(id);
    query.addBindValue(0);
    if (!query.exec()) {
        qDebug() << "Error saving company:" << query.lastError().text();
        ;
    }
}//end of else
}


void jobs::on_pushButton_11_clicked()
{
    QString cn=job5->Company_name;
    QString jn=job5->job_name;
    if(jobs::isJobApplicationExists(cn,jn,id)){

    }
    else{
    QSqlQuery query;
    query.prepare("INSERT INTO job_apply (company_name, job_name, sender_id,v) VALUES (?, ?, ?,?)");
    query.addBindValue(job5->Company_name);
    query.addBindValue(job5->job_name);
    query.addBindValue(id);
    query.addBindValue(0);
    if (!query.exec()) {
        qDebug() << "Error saving company:" << query.lastError().text();
        ;
    }
}//end of else
}


#include "information.h"
#include "ui_information.h"
#include "QMessageBox"
//#include "log_in_page.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//

information::information(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::information)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\project1.db");
    database.open();
    //
}

information::~information()
{
    delete ui;
}

void information::on_pushButton_clicked()
{
    QSqlQuery q;
    QString s1,s2,s3,s4;
    QString name1 ;
    name1 = ui-> lineEdit_5 ->text();
    s1=ui-> lineEdit ->text();
    s2=ui-> lineEdit_2 ->text();
    s3=ui-> lineEdit_3 ->text();
    s4=ui-> lineEdit_4 ->text();
    //if (name1 = ui-> lineEdit_5 ->text());
    q.exec("UPDATE user SET birth='"+s1+"' , job='"+s2+"' , company='"+s3+"' , studyplace='"+s4+"' WHERE name='"+name1+"'");


}





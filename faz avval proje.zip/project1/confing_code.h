#ifndef CONFING_CODE_H
#define CONFING_CODE_H

#include <QMainWindow>

namespace Ui {
class confing_code;
}

class confing_code : public QMainWindow
{
    Q_OBJECT

public:
    explicit confing_code(QWidget *parent = nullptr);
    ~confing_code();




private slots:
    void on_pushButton_2_clicked();

private:
    Ui::confing_code *ui;
};

#endif // CONFING_CODE_H

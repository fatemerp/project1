#include "firstp.h"
#include "ui_firstp.h"
#include "QDebug"
#include "QPixmap"
#include"QPainter"
#include "QMessageBox"
#include "log_in_page.h"
//data base
#include "QSqlDatabase"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//
firstP::firstP(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::firstP)
{
    ui->setupUi(this);
    //data base
    QSqlDatabase database ;
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\project1.db");
    database.open();
    //
    QPixmap background("d:\\New folder\\images (1).jpg");
    QPalette palette;
    palette.setBrush(QPalette::Background, background);
    ui->groupBox_2->setAutoFillBackground(true);
    ui->groupBox_2->setPalette(palette);



}

firstP::~firstP()
{
    delete ui;
}








void firstP::on_pushButton1_clicked()
{
      log_in_page *l =new log_in_page;
      l->setWindowTitle("log in !");
      l->show();

}


//void firstP::on_pushButton_4_clicked()
//{
   // QSqlQuery q;
   //  q.exec("SELECT * FROM user");
    // QSqlQueryModel *m =new QSqlQueryModel;
     //m->setQuery(q);
//
  //  ui->tableView->setModel (m);
   // if (q.first()) QMessageBox::warning(this,"incorrect captcha!","open sucsisfully","try again");
//}


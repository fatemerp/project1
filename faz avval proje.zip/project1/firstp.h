#ifndef FIRSTP_H
#define FIRSTP_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class firstP; }
QT_END_NAMESPACE

class firstP : public QMainWindow
{
    Q_OBJECT

public:
    firstP(QWidget *parent = nullptr);
    ~firstP();

private slots:



    void on_pushButton1_clicked();



private:
    Ui::firstP *ui;
};
#endif // FIRSTP_H
